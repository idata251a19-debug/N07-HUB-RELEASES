const fs=require('fs'),vm=require('vm');
const path=require('path');
const backend=process.argv[2]||'Code_VF_E2W_V25.gs';
if(!/^Code_(VF_E2W|AUTO_EV)_V25\.gs$/.test(backend))throw new Error('backend argument not allowed');
const code=fs.readFileSync(path.join(__dirname,'..','google_sheet_backend',backend),'utf8');
const writes={TON:[],LS:[],VI:[],PIN_TYPES:[],TYPES:[],deletes:[]};
function fakeSheet(name){return {
 getLastRow(){if(name==='TON')return globalThis.__tonRows?globalThis.__tonRows.length+1:1;if(name==='LS')return 1;if(name==='VI')return 2;if(name==='PIN_TYPES')return 1;return 1},
 getLastColumn(){return name==='TON'?8:name==='LS'?9:5},
 getRange(r,c,nr,nc){return {setValues(vals){writes[name].push({r,c,nr,nc,vals:JSON.parse(JSON.stringify(vals))});},getValues(){return []},setValue(v){},clearContent(){}}},
 deleteRows(r,n){writes.deletes.push({r,n})}, appendRow(row){writes[name].push({append:true,row})}
}}
const ctx={console,LockService:{getScriptLock(){return{waitLock(){},releaseLock(){}}}},SpreadsheetApp:{flush(){}},CacheService:{getScriptCache(){return{get(){return null},put(){}}}},PropertiesService:{getScriptProperties(){return{getProperty(){return 'x'},setProperty(){}}}},Utilities:{formatDate(){return '20/08/2026 20:00:00'},getUuid(){return 'u'},computeDigest(){return[]}},Session:{getScriptTimeZone(){return 'Asia/Ho_Chi_Minh'}},ContentService:{MimeType:{JSON:'json'},createTextOutput(){return{setMimeType(){return this}}}},UrlFetchApp:{},writes};
vm.createContext(ctx);vm.runInContext(code,ctx);
// Override I/O helpers for deterministic in-memory QA.
vm.runInContext(`
var __mode='import';var __rows=[];
locationRows=function(){return [['1',72,__mode==='export'?50:0,__mode==='export'?22:72,'']]};
currentRows=function(){return __rows};
pinTypeRows=function(){return []};
ss=function(){return {getSheetByName:function(n){if(n==='PIN_TYPES')return __fake('PIN_TYPES');return __fake(n)}}};
dataSheet=function(n){if(n==='TON_HIEN_TAI')return __fake('TON');if(n==='LICH_SU')return __fake('LS');if(n==='VI_TRI')return __fake('VI');if(n==='PIN_TYPES')return __fake('PIN_TYPES');return __fake(n)};
layoutConfig=function(){return {aisles:1,cells:4,slots:18,capacity:72}};
findLocation=function(){return {row:2}};
`,ctx);
ctx.__fake=fakeSheet;
// 50 imports spread across 3 cells.
let items=[];for(let i=0;i<50;i++){let f=Math.floor(i/18)+1;items.push({clientId:i+1,location:'1',aisle:1,row:1,cell:f,code:'B'+String(i).padStart(3,'0'),pinType:'VF3',clientTime:'20/08/2026 20:00:00'})}
ctx.items=items;
let imp=vm.runInContext(`batchImportPins({items:items,operatorId:'ADMIN',deviceId:'PC'})`,ctx);
if(!imp.ok||imp.success!==50||imp.failed!==0)throw new Error('import result '+JSON.stringify(imp));
if(writes.TON.length!==1||writes.TON[0].vals.length!==50)throw new Error('TON not one setValues 50 '+JSON.stringify(writes.TON.map(x=>x.vals?.length)));
if(writes.LS.length!==1||writes.LS[0].vals.length!==50)throw new Error('LS not one setValues 50');
const importTonSetValues=writes.TON.length,importTonRows=writes.TON[0].vals.length;
// Export 50 contiguous rows should be one grouped delete and one history setValues.
writes.TON.length=0;writes.LS.length=0;writes.VI.length=0;writes.deletes.length=0;writes.PIN_TYPES.length=0;writes.TYPES.length=0;
let rows=[];for(let i=0;i<50;i++)rows.push(['E'+String(i).padStart(3,'0'),'1',i+1,'t','t','PC','ADMIN','VF3']);ctx.rows=rows;vm.runInContext(`__mode='export';__rows=rows`,ctx);
let expItems=[];for(let i=0;i<50;i++)expItems.push({clientId:i+1,code:'E'+String(i).padStart(3,'0'),expectedLocation:'1',expectedSlot:i+1,clientTime:'20/08/2026 20:01:00'});ctx.expItems=expItems;
let ex=vm.runInContext(`batchExportPins({items:expItems,operatorId:'ADMIN',deviceId:'PC'})`,ctx);
if(!ex.ok||ex.success!==50||ex.failed!==0)throw new Error('export result '+JSON.stringify(ex));
if(writes.deletes.length!==1||writes.deletes[0].n!==50)throw new Error('delete not grouped '+JSON.stringify(writes.deletes));
if(writes.LS.length!==1||writes.LS[0].vals.length!==50)throw new Error('export LS not one setValues 50');
console.log(JSON.stringify({PASS:true,backend,importSuccess:imp.success,importTonSetValues,importTonRows,exportSuccess:ex.success,groupedDelete:writes.deletes,historyRows:writes.LS[0].vals.length}));
