# CHANGELOG — N07 HUBDNI ANDROID V14 / API V25

## Hai hạng mục độc lập

- Trang chủ chọn rõ `PIN XE MÁY ĐIỆN VINFAST` hoặc `PIN Ô TÔ ĐIỆN VINFAST`.
- Giữ hai SQLite local, hai Backend và hai bộ snapshot/hàng chờ riêng.
- Chặn phản hồi Backend sai `warehouseId` trước khi ghi local.
- Cảnh báo nếu hạng mục hiện tại còn thao tác pending khi chuyển sang hạng mục khác.
- Chặn chuyển khi tiến trình sync đang chạy; hạng mục chưa từng dùng phải tải
  snapshot đầu tiên thành công, nếu lỗi sẽ tự quay về hạng mục trước.
- Bản cài mới không tạo Dãy giả `01–04` trước khi nhận dữ liệu thật.

## Layout đồng bộ PC v2.5

- VF_E2W: cố định 4 Ô/Kệ.
- AUTO_EV: 1–6 Vị trí/Kệ theo `SO_O` do PC cấu hình.
- Số Kệ và Slot/Ô hoặc Vị trí vẫn đọc `SO_DAY`, `SO_PIN_O`.
- SQLite kiểm tra layout trước khi ghi PIN offline; không chỉ dựa vào UI.
- Giữ nguyên thuật toán slot ID 4.320 để tương thích dữ liệu cũ.

## Phạm vi Android hiện trường

- Giữ Login, Nhập, Xuất, Tồn, Tìm, Vị trí chỉ đọc, Kiểm kê, Lịch sử,
  hàng chờ/xác nhận 5 phút và offline sync.
- Đối chiếu QR thùng/PIN chỉ hiện ở VF_E2W.
- Bỏ đường vào trang Nhập/Xuất trùng lặp; giữ một Lịch sử gần đây.
- Xóa module và dependency Excel khỏi source Android, không chỉ ẩn nút.
- Xóa source quản trị User, Server Master, URL Backend, layout và mật khẩu ADMIN.
- User thường tự đổi mật khẩu khi đang ở VF_E2W để cập nhật đúng User Master và
  cache offline; ADMIN đổi mật khẩu trên PC.
- Không cho đổi tên/cấu hình cấu trúc kho trên Android.

## Kiểm kê

- Bắt buộc chọn Dãy.
- Hiển thị Khớp, Thiếu, Sai vị trí, Ngoài hệ thống và số lần quét trùng.
- `LƯU KIỂM KÊ` ghi local trước và đưa một nghiệp vụ kiểm kê vào hàng chờ sync.

## Sửa lỗi/review

- Sửa lỗi compile ở `LocationSummary.isFull` do tham chiếu `labels` không tồn tại.
- Dashboard và danh sách Dãy dùng sức chứa layout thực, không dùng hằng 4.320
  để báo số trống/đầy.
- Màn Tồn chỉ nạp danh sách PIN và nhãn vị trí; không còn nạp kèm lịch sử,
  kiểm kê và payload Excel không sử dụng.
- Chi tiết Dãy chỉ tạo slot thuộc layout đang dùng (VF tối đa 432, AUTO tối đa
  648), thay vì tạo đủ 4.320 object legacy trên điện thoại.
- Bổ sung import `dart:io` cần cho `SocketException`.
- Nâng source `14.0.0+42`, bắt buộc Backend API `>= 25`.
- Backend đi kèm lấy đúng byte từ PC v2.5 V25.

## Quy tắc upload

- Android tiếp tục lưu từng thao tác vào outbox để dùng offline, xác nhận thủ công
  hoặc tự xác nhận sau 5 phút.
- Khi gửi, Android chia tối đa 10 thao tác `syncBatch` mỗi lượt để giữ `opId`,
  quyền User và khả năng retry từng dòng. Batch 50 của PC là luồng khác.
