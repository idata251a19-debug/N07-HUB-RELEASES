const SHEET_VI_TRI = 'VI_TRI';
const SHEET_TON = 'TON_HIEN_TAI';
const SHEET_LS = 'LICH_SU';
const SHEET_KK = 'KIEM_KE';
const SHEET_USERS = 'USERS';
const SHEET_SESSIONS = 'SESSIONS';
const SHEET_USER_LOG = 'USER_LOG';
const SHEET_SYNC_OPS = 'SYNC_OPS';
const SHEET_RACK_LABELS = 'KE_LABELS';
const SHEET_PIN_TYPES = 'PIN_TYPES';
const WAREHOUSE_ID = 'VF_E2W';
const WAREHOUSE_LABEL = 'PIN XE MÁY ĐIỆN VINFAST';
const API_VERSION = 25;
const BACKEND_ID = 'N07_V23_CLEAN_VF_E2W'; // stable identity; API version changes separately
const ACTIVE_VEHICLE = WAREHOUSE_ID;

const AISLES_PER_SHELF = 6;
const ROWS_PER_AISLE = 10;
const LEGACY_AISLES_PER_SHELF = 3;
const LEGACY_ROWS_PER_AISLE = 6;
const CELLS_PER_ROW = 4;
const BASE_PINS_PER_CELL = 16;
const PINS_PER_CELL = 18;
const EXTRA_PINS_PER_CELL = PINS_PER_CELL - BASE_PINS_PER_CELL;
const LEGACY_PINS_PER_AISLE =
  LEGACY_ROWS_PER_AISLE * CELLS_PER_ROW * BASE_PINS_PER_CELL;
const LEGACY_CAPACITY =
  LEGACY_AISLES_PER_SHELF * LEGACY_PINS_PER_AISLE;
const EXTENDED_ROWS_SLOTS =
  LEGACY_AISLES_PER_SHELF *
  (ROWS_PER_AISLE - LEGACY_ROWS_PER_AISLE) *
  CELLS_PER_ROW *
  BASE_PINS_PER_CELL;
const BASE_CAPACITY =
  AISLES_PER_SHELF * ROWS_PER_AISLE * CELLS_PER_ROW * BASE_PINS_PER_CELL;
const EXTRA_CAPACITY =
  AISLES_PER_SHELF * ROWS_PER_AISLE * CELLS_PER_ROW * EXTRA_PINS_PER_CELL;
const CAPACITY = BASE_CAPACITY + EXTRA_CAPACITY;
const DEFAULT_USER = 'HUBDNI';
const DEFAULT_PASSWORD = 'Cntt@123';
const SECONDARY_PASSWORD = '77779999';
const ADMIN_USER = 'ADMIN';
const ADMIN_PASSWORD = '33337777';
const SESSION_HOURS = 720;
const SCHEMA_VERSION = 'N07_SCHEMA_V25_CLEAN_VF_E2W';

const PERMISSIONS = [
  'NHAP_PIN',
  'XUAT_PIN',
  'VI_TRI',
  'TIM_PIN',
  'KIEM_KE',
  'XUAT_EXCEL',
  'LICH_SU'
];

function doGet(e) {
  return response(handle((e && e.parameter) || {}));
}

function doPost(e) {
  let body = {};
  try {
    body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
  } catch (err) {
    return response({ok:false, code:'bad_json', message:'JSON không hợp lệ.'});
  }
  return response(handle(body));
}

function getBackendMeta(forceRefresh) {
  const cache = CacheService.getScriptCache();
  if (!forceRefresh) {
    const cached = cache.get('N07_BACKEND_META_STABLE');
    if (cached) {
      try { return JSON.parse(cached); } catch (e) {}
    }
  }
  const props = PropertiesService.getScriptProperties();
  let instanceId = String(props.getProperty('N07_INSTANCE_ID') || '');
  if (!instanceId) {
    instanceId = Utilities.getUuid();
    props.setProperty('N07_INSTANCE_ID', instanceId);
  }
  let spreadsheetId = '';
  let spreadsheetName = '';
  try {
    const book = ss();
    spreadsheetId = String(book && book.getId ? book.getId() : '');
    spreadsheetName = String(book && book.getName ? book.getName() : '');
  } catch (e) {}
  const meta = {
    backendId: BACKEND_ID,
    instanceId: instanceId,
    spreadsheetId: spreadsheetId,
    spreadsheetName: spreadsheetName
  };
  cache.put('N07_BACKEND_META_STABLE', JSON.stringify(meta), 21600);
  return meta;
}

function response(obj) {
  if (!obj || typeof obj !== 'object') obj = {ok:false, code:'empty_response'};
  const meta = getBackendMeta(false);
  obj.warehouseId = WAREHOUSE_ID;
  obj.apiVersion = API_VERSION;
  obj.backendId = meta.backendId;
  obj.instanceId = meta.instanceId;
  obj.spreadsheetId = meta.spreadsheetId;
  obj.spreadsheetName = meta.spreadsheetName;
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function handle(req) {
  try {
    const action = clean(req.action);
    // V24 diagnostic endpoint: identity is deliberately unscoped and returns
    // only backend role/version. It never initializes Sheets or exposes data.
    if (action === 'identity') {
      const meta = getBackendMeta(true);
      return {ok:true, apiVersion:API_VERSION, backendId:BACKEND_ID, backend:BACKEND_ID, instanceId:meta.instanceId, spreadsheetId:meta.spreadsheetId, spreadsheetName:meta.spreadsheetName, warehouseId:WAREHOUSE_ID, warehouseLabel:WAREHOUSE_LABEL, userMasterWarehouseId:'VF_E2W', diagnosticOnly:true, cleanBaseline:true, now:nowText()};
    }
    const requestedWarehouse = normalizeWarehouseRequest(req.warehouseId);
    if (requestedWarehouse && requestedWarehouse !== WAREHOUSE_ID) {
      return {ok:false, code:'warehouse_mismatch', message:'Backend này chỉ quản lý PIN XE MÁY ĐIỆN VINFAST; từ chối request của kho khác.'};
    }


    if (action === 'ping') {
      return {ok:true, apiVersion:API_VERSION, backend:BACKEND_ID, warehouseId:WAREHOUSE_ID, message:'N07 HUB V25 batch backend online', cleanBaseline:true, authMaster:true, userMasterWarehouseId:'VF_E2W', now:nowText()};
    }
    // Ultra-light 5s probe: do NOT initialize Sheets or read warehouse rows.
    // CacheService answers most unchanged probes; ScriptProperties is only a durable fallback.
    if (action === 'revision') {
      return {ok:true, warehouseId:WAREHOUSE_ID, revision:getDataRevision(), serverTime:nowText()};
    }

    ensureInfrastructure();
    if (action === 'login') return login(req);
    // Narrow federated-auth endpoint for AUTO_EV. It returns identity/permissions
    // only and never exposes VF_E2W inventory, locations, history or configuration.
    if (action === 'sharedAuthValidate') {
      const sharedAuth = authenticate(req);
      if (!sharedAuth.ok) return sharedAuth;
      return {
        ok:true,
        valid:true,
        authMaster:true,
        userMasterWarehouseId:'VF_E2W',
        user:publicUser(sharedAuth.user)
      };
    }
    // Narrow shared check used by AUTO_EV for destructive actions that require
    // the system Pass cấp 2. No hashes or inventory data are returned.
    if (action === 'sharedVerifySecondary') {
      const sharedAuth = authenticate(req);
      if (!sharedAuth.ok) return sharedAuth;
      const admin = findUser(ADMIN_USER);
      const valid = !!admin && admin.secondaryHash === hashText(String(req.secondaryPassword || ''));
      return {ok:true, valid:valid, authMaster:true, userMasterWarehouseId:'VF_E2W'};
    }

    const auth = authenticate(req);
    if (!auth.ok) return auth;
    req._user = auth.user;
    req.operatorId = auth.user.id;

    if (action === 'syncSnapshot') {
      return {ok:true, apiVersion:API_VERSION, warehouseId:WAREHOUSE_ID, revision:getDataRevision(), snapshot:buildSyncSnapshot(auth.user), vehicleType:WAREHOUSE_ID, user:publicUser(auth.user)};
    }
    if (action === 'fullSnapshot') {
      // Server-master restore contains the full archive. Keep this ADMIN-only. PC v1.9 also removes the Server URL from non-admin local state.
      if (!auth.user.isAdmin) {
        return {ok:false, code:'admin_required', message:'Chỉ ADMIN được tải SERVER MASTER đầy đủ.'};
      }
      return {
        ok:true,
        snapshot:buildSyncSnapshot(auth.user),
        archive:exportData(),
        vehicleType:WAREHOUSE_ID,
        warehouseId:WAREHOUSE_ID,
        apiVersion:API_VERSION,
        revision:getDataRevision(),
        user:publicUser(auth.user)
      };
    }
    if (action === 'syncBatch') return syncBatch(req, auth.user);

    if (action === 'logout') return logoutSession(req);
    if (action === 'me') return {ok:true, user:publicUser(auth.user)};
    if (action === 'changeOwnPassword') return changeOwnPassword(req);
    if (action === 'changeAdminPassword') return changeAdminPassword(req);
    if (action === 'changeSecondaryPassword') return changeSecondaryPassword(req);
    if (action === 'verifySecondary') return verifySecondary(req);

    if (['listUsers','createUser','setUserActive','setUserPermission','deleteUser','userLogs'].indexOf(action) >= 0) {
      if (!auth.user.isAdmin) {
        return {ok:false, code:'admin_required', message:'Chỉ ADMIN được sử dụng chức năng này.'};
      }
      switch (action) {
        case 'listUsers': return listUsers();
        case 'createUser': return createUser(req);
        case 'setUserActive': return setUserActive(req);
        case 'setUserPermission': return setUserPermission(req);
        case 'deleteUser': return deleteUser(req);
        case 'userLogs': return userLogs(req);
      }
    }

    const permissionError = checkActionPermission(auth.user, action);
    if (permissionError) return permissionError;

    switch (action) {
      case 'summary':
        return getSummary();
      case 'homeData':
        return getHomeData(auth.user);
      case 'addLocation':
        return finalizeMutation(action, addLocation(req));
      case 'addLocations':
        return finalizeMutation(action, addLocations(req));
      case 'addLocationsExplicit':
        return finalizeMutation(action, addLocationsExplicit(req));
      case 'deleteLocation':
        return finalizeMutation(action, deleteLocation(req));
      case 'listLocations':
        return listLocations();
      case 'getLocation':
        return getLocation(req);
      case 'importPin':
        return finalizeMutation(action, importPin(req, null));
      case 'importPinAtSlot':
        return finalizeMutation(action, importPin(req, Number(req.slot)));
      case 'importPinToCell':
        return finalizeMutation(action, importPinToCell(req));
      case 'batchImportPins':
        return finalizeMutation(action, batchImportPins(req));
      case 'saveRackLabel':
        return finalizeMutation(action, saveRackLabel(req));
      case 'saveLayoutConfig':
        return finalizeMutation(action, saveLayoutConfig(req));
      case 'exportPin':
        return finalizeMutation(action, exportPin(req));
      case 'batchExportPins':
        return finalizeMutation(action, batchExportPins(req));
      case 'exportSlot':
        return finalizeMutation(action, exportSlot(req));
      case 'replacePin':
        return finalizeMutation(action, replacePin(req));
      case 'searchPin':
        return searchPin(req);
      case 'recentHistory':
        return recentHistory(req);
      case 'listPinTypes':
        return {ok:true, vehicleType:WAREHOUSE_ID, pinTypes:listPinTypes()};
      case 'saveAudit':
        return finalizeMutation(action, saveAudit(req));
      case 'batchMutations':
        return finalizeMutation(action, batchMutations(req));
      case 'exportData':
        return exportData();
      case 'exportDataRange':
        return exportDataRange(req);
      default:
        return {ok:false, code:'unknown_action', message:'Action không hợp lệ: ' + action};
    }
  } catch (err) {
    return {
      ok:false,
      code:'server_error',
      message:String(err && err.message ? err.message : err)
    };
  }
}

function getDataRevision() {
  // Cache-first keeps the 5-second probe extremely light and avoids burning a
  // ScriptProperties read on every poll. Properties is the durable fallback.
  const cache = CacheService.getScriptCache();
  let value = cache.get('N07_DATA_REVISION');
  if (value) return String(value);
  value = String(PropertiesService.getScriptProperties().getProperty('N07_DATA_REVISION') || '1');
  cache.put('N07_DATA_REVISION', value, 21600);
  return value;
}

function bumpDataRevision() {
  // Opaque token instead of an integer counter: concurrent writes can never
  // collapse into the same revision value even when executions overlap.
  const next = String(Date.now()) + '-' + Utilities.getUuid();
  PropertiesService.getScriptProperties().setProperty('N07_DATA_REVISION', next);
  CacheService.getScriptCache().put('N07_DATA_REVISION', next, 21600);
  return next;
}

function isDataMutation(action) {
  return [
    'addLocation','addLocations','addLocationsExplicit','deleteLocation',
    'importPin','importPinAtSlot','importPinToCell','batchImportPins','saveRackLabel','saveLayoutConfig',
    'exportPin','batchExportPins','exportSlot','replacePin','saveAudit','batchMutations'
  ].indexOf(clean(action)) >= 0;
}

function finalizeMutation(action, result) {
  if (result && result.ok === true && isDataMutation(action)) {
    result.revision = bumpDataRevision();
  }
  if (result && typeof result === 'object') {
    result.warehouseId = WAREHOUSE_ID;
    result.apiVersion = API_VERSION;
  }
  return result;
}

function ss() {
  return SpreadsheetApp.getActiveSpreadsheet();
}

function ensureInfrastructure() {
  const props = PropertiesService.getScriptProperties();
  const previousSchema = props.getProperty('N07_SCHEMA_VERSION');
  if (previousSchema === SCHEMA_VERSION) return;

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const currentSchema = props.getProperty('N07_SCHEMA_VERSION');
    if (currentSchema === SCHEMA_VERSION) return;

    setupSheets();
    migrateUsersSheet();
    ensureDefaultUser();
    ensureAdminUser();

    // Chỉ tạo Kệ 01-04 ở hệ thống mới hoàn toàn.
    // Khi nâng từ V5 lên V6 không tự mọc lại Kệ mà ADMIN đã chủ động xóa.
    if (!currentSchema) ensureDefaultShelves();

    migrateRackCapacityV10();
    rebuildLocationStatsFast();

    props.setProperty('N07_SCHEMA_VERSION', SCHEMA_VERSION);
    if (!props.getProperty('N07_DATA_REVISION')) props.setProperty('N07_DATA_REVISION', '1');
  } finally {
    lock.releaseLock();
  }
}

function migrateRackCapacityV10() {
  const sheet = dataSheet(SHEET_VI_TRI);
  const lastRow = sheet.getLastRow();
  if (lastRow >= 2) {
    const count = lastRow - 1;
    const values = Array.from({length: count}, () => [CAPACITY]);
    sheet.getRange(2, 2, count, 1).setValues(values);
  }
  const ton = dataSheet(SHEET_TON);
  if (ton && ton.getLastColumn() >= 3) ton.getRange(1, 3).setValue('Vị trí nội bộ 0001-4320');
  const ls = dataSheet(SHEET_LS);
  if (ls && ls.getLastColumn() >= 5) ls.getRange(1, 5).setValue('Vị trí nội bộ 0001-4320');
  ensureSheetColumn(SHEET_TON, 8, 'Loại pin');
  ensureSheetColumn(SHEET_LS, 9, 'Loại pin');
}

function ensureDefaultShelves() {
  const sheet = dataSheet(SHEET_VI_TRI);
  const existing = {};
  locationRows().forEach(r => existing[clean(r[0])] = true);

  const t = nowText();
  const rows = [];
  ['01', '02', '03', '04'].forEach(id => {
    if (!existing[id]) {
      rows.push([id, CAPACITY, 0, CAPACITY, t]);
    }
  });

  if (rows.length > 0) {
    sheet.getRange(sheet.getLastRow() + 1, 1, rows.length, 5).setValues(rows);
  }
}

function setupSheets() {
  makeSheet(SHEET_VI_TRI, [
    'Kệ', 'Sức chứa', 'Đang có', 'Còn trống', 'Cập nhật cuối'
  ]);
  makeSheet(SHEET_TON, [
    'Mã QR/Text', 'Kệ', 'Vị trí nội bộ 0001-4320', 'Thời gian nhập',
    'Cập nhật cuối', 'Thiết bị', 'Người thao tác'
  ]);
  makeSheet(SHEET_LS, [
    'Thời gian', 'Mã QR/Text', 'Thao tác', 'Kệ',
    'Vị trí nội bộ 0001-4320', 'Ghi chú', 'Thiết bị', 'Người thao tác'
  ]);
  makeSheet(SHEET_KK, [
    'Thời gian', 'Phiên', 'Kệ', 'Hệ thống', 'Đã quét',
    'Khớp', 'Thiếu', 'Sai Kệ', 'Ngoài hệ thống',
    'Quét trùng', 'Chi tiết', 'Người kiểm'
  ]);
  makeSheet(SHEET_USERS, userHeaders());
  makeSheet(SHEET_SESSIONS, [
    'Token', 'User ID', 'Tạo lúc', 'Hết hạn epoch', 'Thiết bị'
  ]);
  makeSheet(SHEET_USER_LOG, [
    'Thời gian', 'Người thực hiện', 'Hành động',
    'User tác động', 'Chi tiết', 'Thiết bị'
  ]);
  makeSheet(SHEET_SYNC_OPS, [
    'OP ID', 'Thời gian', 'User', 'Thiết bị', 'Action', 'Result JSON'
  ]);
  makeSheet(SHEET_RACK_LABELS, [
    'Kệ', 'Loại', 'Dãy', 'Hàng', 'Ô', 'Tên hiển thị', 'Cập nhật cuối'
  ]);
  makeSheet(SHEET_PIN_TYPES, ['Kho', 'Loại pin', 'Tạo lúc', 'Tạo bởi', 'Active']);
  ensureSheetColumn(SHEET_TON, 8, 'Loại pin');
  ensureSheetColumn(SHEET_LS, 9, 'Loại pin');
}

function normalizeWarehouseRequest(value) {
  const v = clean(value).toUpperCase();
  if (!v) return '';
  if (v === 'VF_E2W' || v === 'E2W' || v === 'MOTORBIKE' || v === 'XE MÁY' || v === 'XE MÁY ĐIỆN') return 'VF_E2W';
  if (v === 'AUTO_EV' || v === 'CAR' || v === 'OTO' || v === 'Ô TÔ') return 'AUTO_EV';
  return v;
}

function normalizeVehicle(value) {
  // Legacy Android may still send MOTORBIKE or no vehicleType. This physical
  // backend never switches database based on request data.
  return WAREHOUSE_ID;
}

function vehicleLabel() { return WAREHOUSE_LABEL; }
function vehicleSheetName(base) { return base; }
function dataSheet(base) { return ss().getSheetByName(base); }
function withVehicle(vehicle, fn) { return fn(); }

function ensureSheetColumn(name, col, header) {
  const sheet = ss().getSheetByName(name);
  if (!sheet) return;
  if (sheet.getMaxColumns() < col) sheet.insertColumnsAfter(sheet.getMaxColumns(), col - sheet.getMaxColumns());
  if (clean(sheet.getRange(1, col).getValue()) !== header) sheet.getRange(1, col).setValue(header).setFontWeight('bold').setBackground('#b71c1c').setFontColor('#ffffff');
}


function pinTypeText(value) {
  return clean(value).replace(/[\r\n\t]+/g, ' ').replace(/\s{2,}/g, ' ');
}

function pinTypeRows() {
  return rowsOf(ss().getSheetByName(SHEET_PIN_TYPES));
}

function listPinTypes() {
  const vehicle = ACTIVE_VEHICLE;
  const seen = {};
  const result = [];
  pinTypeRows().forEach(r => {
    if (normalizeWarehouseRequest(r[0]) && normalizeWarehouseRequest(r[0]) !== vehicle) return;
    if (String(r[4]).toLowerCase() === 'false') return;
    const name = pinTypeText(r[1]);
    if (!name) return;
    const key = name.toLowerCase();
    if (!seen[key]) { seen[key] = true; result.push(name); }
  });
  result.sort((a,b) => naturalCompare(a,b));
  return result;
}

function ensurePinType(pinType, operatorId) {
  const value = pinTypeText(pinType);
  if (!value) return '';
  const key = value.toLowerCase();
  const vehicle = ACTIVE_VEHICLE;
  const rows = pinTypeRows();
  for (let i=0;i<rows.length;i++) {
    if ((!normalizeWarehouseRequest(rows[i][0]) || normalizeWarehouseRequest(rows[i][0]) === vehicle) && clean(rows[i][1]).toLowerCase() === key) return clean(rows[i][1]);
  }
  ss().getSheetByName(SHEET_PIN_TYPES).appendRow([vehicle, value, nowText(), clean(operatorId), true]);
  return value;
}

function userHeaders() {
  return [
    'ID', 'Password SHA256', 'Secondary SHA256', 'Role', 'Active',
    'NHAP_PIN', 'XUAT_PIN', 'VI_TRI', 'TIM_PIN', 'KIEM_KE',
    'XUAT_EXCEL', 'LICH_SU', 'Tạo lúc', 'Tạo bởi', 'Cập nhật cuối'
  ];
}

function makeSheet(name, headers) {
  let sheet = ss().getSheetByName(name);
  if (!sheet) sheet = ss().insertSheet(name);
  if (sheet.getLastRow() === 0) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    sheet.getRange(1, 1, 1, headers.length)
      .setFontWeight('bold')
      .setBackground('#b71c1c')
      .setFontColor('#ffffff');
    sheet.autoResizeColumns(1, headers.length);
  }
  return sheet;
}

function migrateUsersSheet() {
  const sheet = ss().getSheetByName(SHEET_USERS);
  const headers = userHeaders();
  const oldHeaders = sheet.getLastColumn() > 0
    ? sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0]
    : [];

  const oldFormat = clean(oldHeaders[3]) === 'Cập nhật cuối' || sheet.getLastColumn() < headers.length;
  const existing = rowsOf(sheet);

  sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
  sheet.setFrozenRows(1);
  sheet.getRange(1, 1, 1, headers.length)
    .setFontWeight('bold')
    .setBackground('#b71c1c')
    .setFontColor('#ffffff');

  if (!oldFormat || existing.length === 0) return;

  for (let i = 0; i < existing.length; i++) {
    const row = existing[i];
    const id = normalizeUserId(row[0]);
    if (!id) continue;
    const oldUpdated = String(row[3] || '');
    const isAdmin = id === ADMIN_USER;
    const grantExisting = isAdmin || id === DEFAULT_USER;
    const values = [
      id,
      String(row[1] || ''),
      String(row[2] || ''),
      isAdmin ? 'ADMIN' : 'USER',
      true,
      grantExisting, grantExisting, grantExisting, grantExisting,
      grantExisting, grantExisting, grantExisting,
      oldUpdated || nowText(),
      'MIGRATION',
      oldUpdated || nowText()
    ];
    sheet.getRange(i + 2, 1, 1, headers.length).setValues([values]);
  }
  SpreadsheetApp.flush();
}

function ensureDefaultUser() {
  if (findUser(DEFAULT_USER)) return;
  const now = nowText();
  ss().getSheetByName(SHEET_USERS).appendRow([
    DEFAULT_USER,
    hashText(DEFAULT_PASSWORD),
    '',
    'USER',
    true,
    true, true, true, true, true, true, true,
    now,
    'SYSTEM',
    now
  ]);
}

function ensureAdminUser() {
  const existing = findUser(ADMIN_USER);
  if (existing) {
    const sheet = ss().getSheetByName(SHEET_USERS);
    sheet.getRange(existing.row, 4).setValue('ADMIN');
    sheet.getRange(existing.row, 5).setValue(true);
    sheet.getRange(existing.row, 6, 1, PERMISSIONS.length)
      .setValues([[true, true, true, true, true, true, true]]);
    if (!existing.secondaryHash) sheet.getRange(existing.row, 3).setValue(hashText(SECONDARY_PASSWORD));
    return;
  }
  const now = nowText();
  ss().getSheetByName(SHEET_USERS).appendRow([
    ADMIN_USER,
    hashText(ADMIN_PASSWORD),
    hashText(SECONDARY_PASSWORD),
    'ADMIN',
    true,
    true, true, true, true, true, true, true,
    now,
    'SYSTEM',
    now
  ]);
}

function login(req) {
  const id = normalizeUserId(req.id);
  const password = String(req.password || '');
  const user = findUser(id);
  if (!user || user.passwordHash !== hashText(password)) {
    return {ok:true, valid:false, message:'Sai ID hoặc mật khẩu.'};
  }
  if (!user.active) {
    return {ok:true, valid:false, message:'Tài khoản đang bị ADMIN khóa.'};
  }

  const token = createSession(user.id, clean(req.deviceId));
  logUserAction(user.id, 'DANG_NHAP', user.id, 'Đăng nhập ứng dụng', clean(req.deviceId));
  return {
    ok:true,
    valid:true,
    sessionToken:token,
    user:publicUser(user)
  };
}

function authenticate(req) {
  const token = clean(req.sessionToken);
  if (!token) {
    return {ok:false, code:'auth_required', message:'Phiên đăng nhập không hợp lệ. Hãy đăng nhập lại.'};
  }
  const session = findSession(token);
  if (!session) {
    return {ok:false, code:'session_expired', message:'Phiên đăng nhập đã hết hạn. Hãy đăng nhập lại.'};
  }
  if (Number(session.expiresEpoch || 0) < Date.now()) {
    deleteSessionRow(session.row);
    return {ok:false, code:'session_expired', message:'Phiên đăng nhập đã hết hạn. Hãy đăng nhập lại.'};
  }
  const user = findUser(session.userId);
  if (!user) {
    return {ok:false, code:'user_not_found', message:'Tài khoản không còn tồn tại.'};
  }
  if (!user.active) {
    return {ok:false, code:'account_disabled', message:'Tài khoản đã bị ADMIN khóa.'};
  }
  touchSession(session.row, session.expiresEpoch);
  return {ok:true, user:user, session:session};
}

function touchSession(row, currentExpiry) {
  if (row < 2) return;
  const sevenDays = 7 * 24 * 60 * 60 * 1000;
  if (Number(currentExpiry || 0) - Date.now() > sevenDays) return;
  const expires = Date.now() + SESSION_HOURS * 60 * 60 * 1000;
  ss().getSheetByName(SHEET_SESSIONS).getRange(row, 4).setValue(expires);
}

function createSession(userId, deviceId) {
  cleanupSessions();
  const token = Utilities.getUuid() + '-' + Utilities.getUuid();
  const expires = Date.now() + SESSION_HOURS * 60 * 60 * 1000;
  ss().getSheetByName(SHEET_SESSIONS).appendRow([
    token, userId, nowText(), expires, deviceId
  ]);
  SpreadsheetApp.flush();
  return token;
}

function findSession(token) {
  const rows = rowsOf(ss().getSheetByName(SHEET_SESSIONS));
  for (let i = rows.length - 1; i >= 0; i--) {
    if (String(rows[i][0] || '') === token) {
      return {
        row:i + 2,
        token:token,
        userId:normalizeUserId(rows[i][1]),
        expiresEpoch:Number(rows[i][3] || 0)
      };
    }
  }
  return null;
}

function cleanupSessions() {
  const sheet = ss().getSheetByName(SHEET_SESSIONS);
  const rows = rowsOf(sheet);
  for (let i = rows.length - 1; i >= 0; i--) {
    if (Number(rows[i][3] || 0) < Date.now()) sheet.deleteRow(i + 2);
  }
}

function deleteSessionRow(row) {
  if (row >= 2) ss().getSheetByName(SHEET_SESSIONS).deleteRow(row);
}

function logoutSession(req) {
  const token = clean(req.sessionToken);
  const found = findSession(token);
  if (found) deleteSessionRow(found.row);
  logUserAction(req._user.id, 'DANG_XUAT', req._user.id, 'Đăng xuất ứng dụng', clean(req.deviceId));
  SpreadsheetApp.flush();
  return {ok:true};
}

function invalidateUserSessions(userId, keepToken) {
  const sheet = ss().getSheetByName(SHEET_SESSIONS);
  const rows = rowsOf(sheet);
  for (let i = rows.length - 1; i >= 0; i--) {
    if (normalizeUserId(rows[i][1]) === userId && String(rows[i][0] || '') !== keepToken) {
      sheet.deleteRow(i + 2);
    }
  }
}

function findUser(id) {
  id = normalizeUserId(id);
  const rows = rowsOf(ss().getSheetByName(SHEET_USERS));
  for (let i = 0; i < rows.length; i++) {
    if (normalizeUserId(rows[i][0]) === id) {
      const role = clean(rows[i][3]).toUpperCase() === 'ADMIN' ? 'ADMIN' : 'USER';
      const permissions = {};
      for (let p = 0; p < PERMISSIONS.length; p++) {
        permissions[PERMISSIONS[p]] = role === 'ADMIN' || asBool(rows[i][5 + p]);
      }
      return {
        row:i + 2,
        id:id,
        passwordHash:String(rows[i][1] || ''),
        secondaryHash:String(rows[i][2] || ''),
        role:role,
        isAdmin:role === 'ADMIN',
        active:role === 'ADMIN' ? true : asBool(rows[i][4]),
        permissions:permissions,
        createdAt:String(rows[i][12] || ''),
        createdBy:String(rows[i][13] || ''),
        updatedAt:String(rows[i][14] || '')
      };
    }
  }
  return null;
}

function publicUser(user) {
  return {
    id:user.id,
    role:user.role,
    active:user.active,
    permissions:user.permissions,
    createdAt:user.createdAt,
    createdBy:user.createdBy,
    updatedAt:user.updatedAt
  };
}

function hasPermission(user, permission) {
  return user.isAdmin || user.permissions[permission] === true;
}

function checkActionPermission(user, action) {
  if (user.isAdmin) return null;

  const direct = {
    'importPin':'NHAP_PIN',
    'importPinAtSlot':'NHAP_PIN',
    'importPinToCell':'NHAP_PIN',
    'batchImportPins':'NHAP_PIN',
    'exportPin':'XUAT_PIN',
    'batchExportPins':'XUAT_PIN',
    'exportSlot':'VI_TRI',
    'replacePin':'VI_TRI',
    'addLocation':'VI_TRI',
    'addLocations':'VI_TRI',
    'addLocationsExplicit':'VI_TRI',
    'deleteLocation':'VI_TRI',
    'saveRackLabel':'VI_TRI',
    'saveLayoutConfig':'VI_TRI',
    'searchPin':'TIM_PIN',
    'saveAudit':'KIEM_KE',
    'exportData':'XUAT_EXCEL',
    'exportDataRange':'XUAT_EXCEL',
    'recentHistory':'LICH_SU'
  };

  if (direct[action] && !hasPermission(user, direct[action])) {
    return permissionDenied(direct[action]);
  }

  if (action === 'listLocations' || action === 'getLocation' || action === 'listPinTypes') {
    if (!hasPermission(user, 'NHAP_PIN') && !hasPermission(user, 'VI_TRI') && !hasPermission(user, 'KIEM_KE')) {
      return {ok:false, code:'permission_denied', message:'Tài khoản chưa được cấp quyền sử dụng dữ liệu Kệ.'};
    }
  }

  return null;
}

function permissionDenied(permission) {
  return {
    ok:false,
    code:'permission_denied',
    message:'Tài khoản chưa được ADMIN cấp quyền ' + permission + '.'
  };
}

function listUsers() {
  const rows = rowsOf(ss().getSheetByName(SHEET_USERS));
  const result = [];
  for (let i = 0; i < rows.length; i++) {
    const user = findUser(rows[i][0]);
    if (user) result.push(publicUser(user));
  }
  result.sort((a, b) => a.id === ADMIN_USER ? -1 : (b.id === ADMIN_USER ? 1 : a.id.localeCompare(b.id)));
  return {ok:true, users:result};
}

function createUser(req) {
  const actor = req._user;
  const id = normalizeUserId(req.id);
  const password = String(req.password || '');

  if (!/^[A-Z0-9._-]{3,30}$/.test(id)) {
    return {ok:false, code:'bad_user_id', message:'ID chỉ dùng A-Z, 0-9, dấu chấm, gạch dưới hoặc gạch ngang; dài 3-30 ký tự.'};
  }
  if (password.length < 6) {
    return {ok:false, code:'weak_password', message:'Mật khẩu phải từ 6 ký tự.'};
  }
  if (findUser(id)) {
    return {ok:false, code:'user_exists', message:'User ' + id + ' đã tồn tại.'};
  }

  const now = nowText();
  ss().getSheetByName(SHEET_USERS).appendRow([
    id,
    hashText(password),
    '',
    'USER',
    true,
    false, false, false, false, false, false, false,
    now,
    actor.id,
    now
  ]);
  logUserAction(actor.id, 'TAO_USER', id, 'Tạo user mới, chưa cấp quyền hạng mục nào', clean(req.deviceId));
  SpreadsheetApp.flush();
  return {ok:true};
}

function setUserActive(req) {
  const actor = req._user;
  const id = normalizeUserId(req.id);
  const active = asBool(req.active);
  const user = findUser(id);
  if (!user) return {ok:false, code:'user_not_found', message:'Không tìm thấy user.'};
  if (user.isAdmin) return {ok:false, code:'cannot_modify_admin', message:'Không thể khóa tài khoản ADMIN.'};
  const sheet = ss().getSheetByName(SHEET_USERS);
  sheet.getRange(user.row, 5).setValue(active);
  sheet.getRange(user.row, 15).setValue(nowText());
  if (!active) invalidateUserSessions(id, '');
  logUserAction(actor.id, active ? 'MO_TAI_KHOAN' : 'KHOA_TAI_KHOAN', id,
    active ? 'Mở quyền truy cập tài khoản' : 'Khóa toàn bộ quyền truy cập tài khoản', clean(req.deviceId));
  SpreadsheetApp.flush();
  return {ok:true};
}


function deleteUser(req) {
  const actor = req._user;
  const id = normalizeUserId(req.id);
  const user = findUser(id);
  if (!user) return {ok:false, code:'user_not_found', message:'Không tìm thấy user.'};
  if (user.isAdmin) return {ok:false, code:'cannot_delete_admin', message:'Không thể xóa tài khoản ADMIN.'};
  if (actor.secondaryHash !== hashText(String(req.secondaryPassword || ''))) {
    return {ok:false, code:'bad_secondary', message:'Pass cấp 2 không đúng.'};
  }

  invalidateUserSessions(id, '');
  const sheet = ss().getSheetByName(SHEET_USERS);
  sheet.deleteRow(user.row);
  logUserAction(actor.id, 'XOA_USER', id, 'Xóa vĩnh viễn tài khoản user', clean(req.deviceId));
  SpreadsheetApp.flush();
  return {ok:true, deleted:id};
}

function setUserPermission(req) {
  const actor = req._user;
  const id = normalizeUserId(req.id);
  const permission = clean(req.permission).toUpperCase();
  const enabled = asBool(req.enabled);
  const user = findUser(id);
  if (!user) return {ok:false, code:'user_not_found', message:'Không tìm thấy user.'};
  if (user.isAdmin) return {ok:false, code:'cannot_modify_admin', message:'ADMIN luôn có toàn bộ quyền.'};

  const index = PERMISSIONS.indexOf(permission);
  if (index < 0) return {ok:false, code:'bad_permission', message:'Hạng mục quyền không hợp lệ.'};

  const sheet = ss().getSheetByName(SHEET_USERS);
  sheet.getRange(user.row, 6 + index).setValue(enabled);
  sheet.getRange(user.row, 15).setValue(nowText());
  logUserAction(actor.id, enabled ? 'CAP_QUYEN' : 'TAT_QUYEN', id,
    permission + ' = ' + (enabled ? 'ON' : 'OFF'), clean(req.deviceId));
  SpreadsheetApp.flush();
  return {ok:true};
}

function changeOwnPassword(req) {
  const user = req._user;
  if (user.isAdmin) {
    return {ok:false, code:'admin_password_rule', message:'ADMIN phải đổi mật khẩu bằng Pass cấp 2.'};
  }
  const current = String(req.currentPassword || '');
  const next = String(req.newPassword || '');
  if (next.length < 6) return {ok:false, code:'weak_password', message:'Mật khẩu mới phải từ 6 ký tự.'};
  if (user.passwordHash !== hashText(current)) {
    return {ok:false, code:'bad_current_password', message:'Mật khẩu hiện tại không đúng.'};
  }

  const sheet = ss().getSheetByName(SHEET_USERS);
  sheet.getRange(user.row, 2).setValue(hashText(next));
  sheet.getRange(user.row, 15).setValue(nowText());
  invalidateUserSessions(user.id, clean(req.sessionToken));
  logUserAction(user.id, 'DOI_MAT_KHAU', user.id, 'User tự đổi mật khẩu', clean(req.deviceId));
  SpreadsheetApp.flush();
  return {ok:true};
}

function changeAdminPassword(req) {
  const user = req._user;
  if (!user.isAdmin) return {ok:false, code:'admin_required', message:'Chỉ ADMIN được sử dụng chức năng này.'};
  const second = String(req.secondaryPassword || '');
  const next = String(req.newPassword || '');
  if (next.length < 6) return {ok:false, code:'weak_password', message:'Mật khẩu mới phải từ 6 ký tự.'};
  if (user.secondaryHash !== hashText(second)) {
    return {ok:false, code:'bad_secondary', message:'Pass cấp 2 không đúng.'};
  }

  const sheet = ss().getSheetByName(SHEET_USERS);
  sheet.getRange(user.row, 2).setValue(hashText(next));
  sheet.getRange(user.row, 15).setValue(nowText());
  invalidateUserSessions(user.id, clean(req.sessionToken));
  logUserAction(user.id, 'DOI_MAT_KHAU_ADMIN', user.id, 'Đổi mật khẩu ADMIN bằng Pass cấp 2', clean(req.deviceId));
  SpreadsheetApp.flush();
  return {ok:true};
}

function changeSecondaryPassword(req) {
  const user = req._user;
  if (!user.isAdmin) return {ok:false, code:'admin_required', message:'Chỉ ADMIN có Pass cấp 2.'};
  const current = String(req.currentSecondary || '');
  const next = String(req.newSecondary || '');
  if (next.length < 6) return {ok:false, code:'weak_secondary', message:'Pass cấp 2 mới phải từ 6 ký tự.'};
  if (user.secondaryHash !== hashText(current)) {
    return {ok:false, code:'bad_secondary', message:'Pass cấp 2 hiện tại không đúng.'};
  }

  const sheet = ss().getSheetByName(SHEET_USERS);
  sheet.getRange(user.row, 3).setValue(hashText(next));
  sheet.getRange(user.row, 15).setValue(nowText());
  logUserAction(user.id, 'DOI_PASS_CAP_2', user.id, 'Đổi Pass cấp 2', clean(req.deviceId));
  SpreadsheetApp.flush();
  return {ok:true};
}

function verifySecondary(req) {
  const user = req._user;
  if (!user.isAdmin) return {ok:false, code:'admin_required', message:'Chỉ ADMIN được xác nhận Pass cấp 2.'};
  return {ok:true, valid:user.secondaryHash === hashText(String(req.secondaryPassword || ''))};
}

function userLogs(req) {
  const limit = Math.max(1, Math.min(500, Number(req.limit || 300)));
  const rows = rowsOf(ss().getSheetByName(SHEET_USER_LOG));
  const result = [];
  for (let i = rows.length - 1; i >= 0 && result.length < limit; i--) {
    const r = rows[i];
    result.push({
      timestamp:String(r[0] || ''),
      actor:String(r[1] || ''),
      action:String(r[2] || ''),
      targetUser:String(r[3] || ''),
      detail:String(r[4] || ''),
      deviceId:String(r[5] || '')
    });
  }
  return {ok:true, logs:result};
}

function logUserAction(actor, action, targetUser, detail, deviceId) {
  ss().getSheetByName(SHEET_USER_LOG).appendRow([
    nowText(), actor, action, targetUser, detail, deviceId
  ]);
}

function normalizeUserId(value) {
  return clean(value).toUpperCase();
}

function asBool(value) {
  if (value === true) return true;
  const s = clean(value).toLowerCase();
  return s === 'true' || s === '1' || s === 'yes' || s === 'on';
}

function hashText(value) {
  const bytes = Utilities.computeDigest(
    Utilities.DigestAlgorithm.SHA_256,
    String(value),
    Utilities.Charset.UTF_8
  );
  return bytes.map(b => {
    const v = b < 0 ? b + 256 : b;
    return ('0' + v.toString(16)).slice(-2);
  }).join('');
}


function baseAisleFromPosition(position) {
  const p = Number(position || 0);
  if (p < 1) return 0;

  if (p <= LEGACY_CAPACITY) {
    return Math.floor((p - 1) / LEGACY_PINS_PER_AISLE) + 1;
  }

  const extendedRowsEnd = LEGACY_CAPACITY + EXTENDED_ROWS_SLOTS;
  if (p <= extendedRowsEnd) {
    const offset = p - LEGACY_CAPACITY - 1;
    const pinsPerExtendedAisle =
      (ROWS_PER_AISLE - LEGACY_ROWS_PER_AISLE) *
      CELLS_PER_ROW * BASE_PINS_PER_CELL;
    return Math.floor(offset / pinsPerExtendedAisle) + 1;
  }

  const offset = p - extendedRowsEnd - 1;
  const pinsPerFullAisle =
    ROWS_PER_AISLE * CELLS_PER_ROW * BASE_PINS_PER_CELL;
  return LEGACY_AISLES_PER_SHELF +
    Math.floor(offset / pinsPerFullAisle) + 1;
}

function baseRowFromPosition(position) {
  const p = Number(position || 0);
  if (p < 1) return 0;

  if (p <= LEGACY_CAPACITY) {
    const withinAisle = (p - 1) % LEGACY_PINS_PER_AISLE;
    return Math.floor(
      withinAisle / (CELLS_PER_ROW * BASE_PINS_PER_CELL)
    ) + 1;
  }

  const extendedRowsEnd = LEGACY_CAPACITY + EXTENDED_ROWS_SLOTS;
  if (p <= extendedRowsEnd) {
    const offset = p - LEGACY_CAPACITY - 1;
    const pinsPerExtendedAisle =
      (ROWS_PER_AISLE - LEGACY_ROWS_PER_AISLE) *
      CELLS_PER_ROW * BASE_PINS_PER_CELL;
    const withinAisle = offset % pinsPerExtendedAisle;
    return LEGACY_ROWS_PER_AISLE +
      Math.floor(withinAisle / (CELLS_PER_ROW * BASE_PINS_PER_CELL)) + 1;
  }

  const offset = p - extendedRowsEnd - 1;
  const pinsPerFullAisle =
    ROWS_PER_AISLE * CELLS_PER_ROW * BASE_PINS_PER_CELL;
  const withinAisle = offset % pinsPerFullAisle;
  return Math.floor(
    withinAisle / (CELLS_PER_ROW * BASE_PINS_PER_CELL)
  ) + 1;
}

function baseCellFromPosition(position) {
  const p = Number(position || 0);
  if (p < 1) return 0;
  return Math.floor(
    ((p - 1) % (CELLS_PER_ROW * BASE_PINS_PER_CELL)) /
    BASE_PINS_PER_CELL
  ) + 1;
}

function basePinInCell(position) {
  const p = Number(position || 0);
  if (p < 1) return 0;
  return ((p - 1) % BASE_PINS_PER_CELL) + 1;
}

function baseSlotFromParts(aisle, row, cell, pinNo) {
  aisle = Number(aisle);
  row = Number(row);
  cell = Number(cell);
  pinNo = Number(pinNo);

  if (aisle <= LEGACY_AISLES_PER_SHELF &&
      row <= LEGACY_ROWS_PER_AISLE) {
    return (((aisle - 1) * LEGACY_ROWS_PER_AISLE + (row - 1)) *
      CELLS_PER_ROW + (cell - 1)) * BASE_PINS_PER_CELL + pinNo;
  }

  if (aisle <= LEGACY_AISLES_PER_SHELF) {
    const rowsBeyondLegacy = row - LEGACY_ROWS_PER_AISLE - 1;
    const pinsPerExtendedAisle =
      (ROWS_PER_AISLE - LEGACY_ROWS_PER_AISLE) *
      CELLS_PER_ROW * BASE_PINS_PER_CELL;
    return LEGACY_CAPACITY +
      (aisle - 1) * pinsPerExtendedAisle +
      rowsBeyondLegacy * CELLS_PER_ROW * BASE_PINS_PER_CELL +
      (cell - 1) * BASE_PINS_PER_CELL +
      pinNo;
  }

  const extendedRowsEnd = LEGACY_CAPACITY + EXTENDED_ROWS_SLOTS;
  const pinsPerFullAisle =
    ROWS_PER_AISLE * CELLS_PER_ROW * BASE_PINS_PER_CELL;
  return extendedRowsEnd +
    (aisle - LEGACY_AISLES_PER_SHELF - 1) * pinsPerFullAisle +
    (row - 1) * CELLS_PER_ROW * BASE_PINS_PER_CELL +
    (cell - 1) * BASE_PINS_PER_CELL +
    pinNo;
}

function extraCellOrdinal(aisle, row, cell) {
  return ((Number(aisle) - 1) * ROWS_PER_AISLE + (Number(row) - 1)) *
    CELLS_PER_ROW + (Number(cell) - 1);
}

function aisleFromPosition(position) {
  const p = Number(position || 0);
  if (p < 1) return 0;
  if (p <= BASE_CAPACITY) return baseAisleFromPosition(p);

  const extra = p - BASE_CAPACITY - 1;
  const cellOrdinal = Math.floor(extra / EXTRA_PINS_PER_CELL);
  return Math.floor(cellOrdinal / (ROWS_PER_AISLE * CELLS_PER_ROW)) + 1;
}

function rowFromPosition(position) {
  const p = Number(position || 0);
  if (p < 1) return 0;
  if (p <= BASE_CAPACITY) return baseRowFromPosition(p);

  const extra = p - BASE_CAPACITY - 1;
  const cellOrdinal = Math.floor(extra / EXTRA_PINS_PER_CELL);
  const withinAisle = cellOrdinal % (ROWS_PER_AISLE * CELLS_PER_ROW);
  return Math.floor(withinAisle / CELLS_PER_ROW) + 1;
}

function cellFromPosition(position) {
  const p = Number(position || 0);
  if (p < 1) return 0;
  if (p <= BASE_CAPACITY) return baseCellFromPosition(p);

  const extra = p - BASE_CAPACITY - 1;
  const cellOrdinal = Math.floor(extra / EXTRA_PINS_PER_CELL);
  return (cellOrdinal % CELLS_PER_ROW) + 1;
}

function pinInCell(position) {
  const p = Number(position || 0);
  if (p < 1) return 0;
  if (p <= BASE_CAPACITY) return basePinInCell(p);

  const extra = p - BASE_CAPACITY - 1;
  return BASE_PINS_PER_CELL + (extra % EXTRA_PINS_PER_CELL) + 1;
}

function slotFromParts(aisle, row, cell, pinNo) {
  aisle = Number(aisle);
  row = Number(row);
  cell = Number(cell);
  pinNo = Number(pinNo);

  if (pinNo <= BASE_PINS_PER_CELL) {
    return baseSlotFromParts(aisle, row, cell, pinNo);
  }

  const ordinal = extraCellOrdinal(aisle, row, cell);
  return BASE_CAPACITY +
    ordinal * EXTRA_PINS_PER_CELL +
    (pinNo - BASE_PINS_PER_CELL);
}

function cellSlotNumbers(aisle, row, cell) {
  const result = [];
  for (let pinNo = 1; pinNo <= PINS_PER_CELL; pinNo++) {
    result.push(slotFromParts(aisle, row, cell, pinNo));
  }
  return result;
}

function positionText(position) {
  return 'Dãy ' + aisleFromPosition(position) +
    ' - Hàng ' + rowFromPosition(position) +
    ' - Ô ' + cellFromPosition(position) +
    ' - Pin ' + String(pinInCell(position)).padStart(2, '0');
}

function buildSyncSnapshot(user) {
  if (user && !user.isAdmin) {
    const canReadWarehouse = PERMISSIONS.some(p => hasPermission(user, p));
    if (!canReadWarehouse) return {serverTime:nowText(), locations:[], pins:[]};
  }
  const locations = locationRows().map(r => ({
    location:clean(r[0]),
    capacity:Number(r[1] || CAPACITY),
    occupied:Number(r[2] || 0),
    empty:Number(r[3] || 0),
    updatedAt:String(r[4] || '')
  }));

  const pins = currentRows().map(r => ({
    code:String(r[0] || ''),
    location:clean(r[1]),
    slot:Number(r[2] || 0),
    aisle:aisleFromPosition(Number(r[2] || 0)),
    row:rowFromPosition(Number(r[2] || 0)),
    cell:cellFromPosition(Number(r[2] || 0)),
    pinInCell:pinInCell(Number(r[2] || 0)),
    storedAt:String(r[3] || ''),
    updatedAt:String(r[4] || ''),
    deviceId:String(r[5] || ''),
    operatorId:String(r[6] || ''),
    pinType:String(r[7] || '')
  }));

  const labels = rackLabelRows().map(r => ({
    location:clean(r[0]),
    kind:clean(r[1]),
    aisle:Number(r[2] || 0),
    row:Number(r[3] || 0),
    cell:Number(r[4] || 0),
    label:String(r[5] || ''),
    updatedAt:String(r[6] || '')
  }));

  return {
    serverTime:nowText(),
    locations:locations,
    pins:pins,
    labels:labels,
    pinTypes:listPinTypes(),
    vehicleType:WAREHOUSE_ID
  };
}

function syncBatch(req, user) {
  const ops = parseJsonArray(req.ops);
  if (!Array.isArray(ops)) {
    return {ok:false, code:'bad_ops', message:'Danh sách đồng bộ không hợp lệ.'};
  }
  if (ops.length > 10) {
    return {ok:false, code:'too_many_ops', message:'Mỗi lần đồng bộ tối đa 10 thao tác.'};
  }

  const processed = processedOpsMap();
  const results = [];
  const rowsToAppend = [];
  const actorAuthCache = {};
  let inventoryChanged = false;

  ops.forEach(opRaw => {
    const op = opRaw && typeof opRaw === 'object' ? opRaw : {};
    const opId = clean(op.opId);
    const action = clean(op.action);
    const payload = op.payload && typeof op.payload === 'object' ? op.payload : {};

    if (!opId || !action) {
      results.push({
        ok:false,
        opId:opId,
        action:action,
        code:'bad_op',
        message:'Thiếu opId hoặc action.'
      });
      return;
    }

    if (processed[opId]) {
      const oldResult = processed[opId];
      oldResult.opId = opId;
      oldResult.action = action;
      oldResult.replayed = true;
      results.push(oldResult);
      return;
    }

    // Each offline operation carries the session of the user who actually
    // performed it. This is critical on a shared phone: User B may reconnect
    // and trigger sync for an operation created earlier by User A, but the
    // server must still enforce User A's permissions and history attribution.
    const actorToken = clean(payload._actorSessionToken);
    const claimedActorId = normalizeUserId(payload._actorId);
    let actorAuth = null;
    if (actorToken) {
      if (actorAuthCache[actorToken]) {
        actorAuth = actorAuthCache[actorToken];
      } else {
        actorAuth = authenticate({sessionToken:actorToken});
        actorAuthCache[actorToken] = actorAuth;
      }
    } else {
      actorAuth = {ok:true, user:user, session:{token:clean(req.sessionToken)}};
    }

    let result;
    let actorUser = user;
    if (!actorAuth || actorAuth.ok !== true) {
      result = actorAuth || {ok:false, code:'auth_required', message:'Không xác thực được người tạo thao tác offline.'};
    } else if (claimedActorId && actorAuth.user.id !== claimedActorId) {
      result = {ok:false, code:'actor_mismatch', message:'Tài khoản tạo thao tác offline không khớp phiên xác thực.'};
    } else {
      actorUser = actorAuth.user;
      const permissionError = checkActionPermission(actorUser, action);
      if (permissionError) {
        result = permissionError;
      } else {
        const child = {};
        Object.keys(payload).forEach(k => {
          if (String(k).indexOf('_actor') !== 0) child[k] = payload[k];
        });
        child._user = actorUser;
        child.operatorId = actorUser.id;
        child.deviceId = clean(payload._actorDeviceId) || clean(req.deviceId);
        child.sessionToken = actorToken || clean(req.sessionToken);
        child._batchSync = true;
        child.vehicleType = WAREHOUSE_ID;
        result = finalizeMutation(action, dispatchSyncedOperation(action, child));
      }
    }

    const wrapped = Object.assign({}, result || {ok:false, code:'empty_result'});
    wrapped.opId = opId;
    wrapped.action = action;
    results.push(wrapped);
    if (wrapped.ok === true && ['importPin','importPinAtSlot','importPinToCell','exportPin','exportSlot','replacePin','addLocationsExplicit','deleteLocation','saveLayoutConfig'].indexOf(action) >= 0) {
      inventoryChanged = true;
    }

    rowsToAppend.push([
      opId,
      nowText(),
      (actorUser && actorUser.id) ? actorUser.id : user.id,
      clean(payload._actorDeviceId) || clean(req.deviceId),
      action,
      JSON.stringify(wrapped)
    ]);
    processed[opId] = wrapped;
  });

  if (inventoryChanged) rebuildLocationStatsFast();

  if (rowsToAppend.length > 0) {
    const sheet = ss().getSheetByName(SHEET_SYNC_OPS);
    sheet.getRange(sheet.getLastRow() + 1, 1, rowsToAppend.length, 6)
      .setValues(rowsToAppend);
  }
  SpreadsheetApp.flush();

  const resultsOnly = String(req.resultsOnly || '') === '1' ||
    req.resultsOnly === true;

  if (resultsOnly) {
    return {
      ok:true,
      results:results,
      user:publicUser(user),
      serverTime:nowText(),
      warehouseId:WAREHOUSE_ID,
      apiVersion:API_VERSION,
      revision:getDataRevision()
    };
  }

  return {
    ok:true,
    results:results,
    snapshot:buildSyncSnapshot(user),
    user:publicUser(user),
    warehouseId:WAREHOUSE_ID,
    apiVersion:API_VERSION,
    revision:getDataRevision()
  };
}

function dispatchSyncedOperation(action, req) {
  switch (action) {
    case 'importPin': return finalizeMutation(action, importPin(req, null));
    case 'importPinAtSlot': return finalizeMutation(action, importPin(req, Number(req.slot)));
    case 'importPinToCell': return finalizeMutation(action, importPinToCell(req));
    case 'saveRackLabel': return finalizeMutation(action, saveRackLabel(req));
    case 'saveLayoutConfig': return finalizeMutation(action, saveLayoutConfig(req));
    case 'exportPin': return finalizeMutation(action, exportPin(req));
    case 'exportSlot': return finalizeMutation(action, exportSlot(req));
    case 'replacePin': return finalizeMutation(action, replacePin(req));
    case 'addLocationsExplicit': return finalizeMutation(action, addLocationsExplicit(req));
    case 'deleteLocation': return finalizeMutation(action, deleteLocation(req));
    case 'saveAudit': return finalizeMutation(action, saveAudit(req));
    default:
      return {ok:false, code:'unsupported_sync_action', message:'Không hỗ trợ đồng bộ action: ' + action};
  }
}

function processedOpsMap() {
  const sheet = ss().getSheetByName(SHEET_SYNC_OPS);
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return {};
  const startRow = Math.max(2, lastRow - 4999);
  const rows = sheet.getRange(startRow, 1, lastRow - startRow + 1, 6).getValues();
  const out = {};
  rows.forEach(r => {
    const id = clean(r[0]);
    if (!id) return;
    try {
      out[id] = JSON.parse(String(r[5] || '{}'));
    } catch (_) {
      out[id] = {ok:true, code:'already_processed'};
    }
  });
  return out;
}

function getSummary() {
  const locations = locationRows();

  let totalPins = 0;
  let full = 0;
  let totalCapacity = 0;
  locations.forEach(r => {
    const occupied = Number(r[2] || 0);
    const capacity = Number(r[1] || CAPACITY) || CAPACITY;
    totalPins += occupied;
    totalCapacity += capacity;
    if (occupied >= capacity) full++;
  });

  return {
    ok:true,
    totalPins:totalPins,
    totalLocations:locations.length,
    fullLocations:full,
    emptySlots:Math.max(0, totalCapacity - totalPins),
    vehicleType:WAREHOUSE_ID,
    vehicleLabel:vehicleLabel()
  };
}

function getHomeData(user) {
  const s = getSummary();
  return {
    ok:true,
    summary:{
      totalPins:s.totalPins,
      totalLocations:s.totalLocations,
      fullLocations:s.fullLocations,
      emptySlots:s.emptySlots
    },
    user:publicUser(user)
  };
}

function addLocation(req) {
  const location = clean(req.location);
  if (!location) {
    return {ok:false, code:'bad_location', message:'Kệ không hợp lệ.'};
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    if (findLocation(location)) {
      return {ok:false, code:'exists', message:'Kệ số ' + Number(location || 0) + ' đã tồn tại.'};
    }

    dataSheet(SHEET_VI_TRI).appendRow([
      location, CAPACITY, 0, CAPACITY, nowText()
    ]);
    SpreadsheetApp.flush();
    return {ok:true, location:location};
  } finally {
    lock.releaseLock();
  }
}

function addLocations(req) {
  const count = Math.floor(Number(req.count || 0));
  if (count < 1 || count > 100) {
    return {ok:false, code:'bad_count', message:'Số lượng Kệ phải từ 1 đến 100.'};
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const rows = locationRows();
    const existing = {};
    let maxNumber = 0;
    let width = 2;

    rows.forEach(r => {
      const id = clean(r[0]);
      if (!id) return;
      existing[id] = true;

      if (/^\d+$/.test(id)) {
        const n = Number(id);
        if (n > maxNumber) maxNumber = n;
        if (id.length > width) width = id.length;
      }
    });

    const created = [];
    const values = [];
    let n = maxNumber + 1;
    const t = nowText();

    while (created.length < count) {
      const id = String(n).padStart(width, '0');
      if (!existing[id]) {
        existing[id] = true;
        created.push(id);
        values.push([id, CAPACITY, 0, CAPACITY, t]);
      }
      n++;
    }

    const sheet = dataSheet(SHEET_VI_TRI);
    sheet.getRange(sheet.getLastRow() + 1, 1, values.length, 5).setValues(values);
    SpreadsheetApp.flush();

    return {ok:true, created:created};
  } finally {
    lock.releaseLock();
  }
}



function addLocationsExplicit(req) {
  const values = parseJsonArray(req.locations).map(clean).filter(Boolean);
  if (values.length < 1 || values.length > 100) {
    return {ok:false, code:'bad_count', message:'Số lượng Dãy phải từ 1 đến 100.'};
  }
  const cfg = {
    aisles:clampInt(req.aisles, 1, AISLES_PER_SHELF, AISLES_PER_SHELF),
    cells:clampInt(req.cells, 1, ROWS_PER_AISLE * CELLS_PER_ROW, ROWS_PER_AISLE * CELLS_PER_ROW),
    slots:clampInt(req.slots, 1, PINS_PER_CELL, PINS_PER_CELL)
  };
  cfg.capacity = cfg.aisles * cfg.cells * cfg.slots;

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const existing = {};
    locationRows().forEach(r => existing[clean(r[0])] = true);
    const duplicate = values.find(id => existing[id]);
    if (duplicate) return {ok:false, code:'exists', message:'Dãy số ' + Number(duplicate || 0) + ' đã tồn tại.'};
    const t = clean(req.clientTime) || nowText();
    const rows = values.map(id => [id, cfg.capacity, 0, cfg.capacity, t]);
    const sheet = dataSheet(SHEET_VI_TRI);
    sheet.getRange(sheet.getLastRow() + 1, 1, rows.length, 5).setValues(rows);
    values.forEach(id => {
      upsertRackLabelValue(id, 'SO_DAY', cfg.aisles, t);
      upsertRackLabelValue(id, 'SO_O', cfg.cells, t);
      upsertRackLabelValue(id, 'SO_PIN_O', cfg.slots, t);
    });
    logUserAction(clean(req.operatorId), 'THEM_KE', '', vehicleLabel() + ' • Thêm Dãy: ' + values.map(v => Number(v || 0)).join(', ') + ' • ' + cfg.aisles + ' Kệ × ' + cfg.cells + ' Ô × ' + cfg.slots + ' Slot', clean(req.deviceId));
    values.forEach(id => logHistory('', 'THEM_KE', id, 0, 'Thêm Dãy số ' + Number(id || 0), clean(req.deviceId), clean(req.operatorId), t));
    if (!req._batchSync) SpreadsheetApp.flush();
    return {ok:true, created:values, layout:cfg};
  } finally { lock.releaseLock(); }
}

function deleteLocation(req) {
  const location = clean(req.location);
  if (!location) {
    return {ok:false, code:'bad_location', message:'Dãy không hợp lệ.'};
  }
  const admin = findUser(ADMIN_USER);
  if (!admin || admin.secondaryHash !== hashText(String(req.secondaryPassword || ''))) {
    return {ok:false, code:'bad_secondary', message:'Pass cấp 2 không đúng.'};
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const meta = findLocation(location);
    if (!meta) {
      return {ok:false, code:'not_found', message:'Không tìm thấy Dãy số ' + Number(location || 0) + '.'};
    }

    const occupied = countLocationPins(location);
    if (occupied > 0) {
      return {
        ok:false,
        code:'location_not_empty',
        message:'Dãy số ' + Number(location || 0) + ' đang có ' + occupied +
          ' pin. Phải xuất/chuyển hết pin trước khi xóa.'
      };
    }

    dataSheet(SHEET_VI_TRI).deleteRow(meta.row);
    deleteRackLabelsForLocation(location);
    logUserAction(
      clean(req.operatorId),
      'XOA_KE',
      '',
      vehicleLabel() + ' • Xóa Dãy số ' + Number(location || 0),
      clean(req.deviceId)
    );
    logHistory(
      '', 'XOA_KE', location, 0,
      vehicleLabel() + ' • Xóa Dãy số ' + Number(location || 0),
      clean(req.deviceId),
      clean(req.operatorId),
      clean(req.clientTime)
    );

    if (!req._batchSync) SpreadsheetApp.flush();
    return {ok:true, location:location};
  } finally {
    lock.releaseLock();
  }
}


// V24: configurable usable layout inside the fixed compatibility envelope
// 6 Kệ × 40 Ô × 18 Slot. Storage slot IDs remain backward compatible.
function clampInt(value, minValue, maxValue, fallback) {
  const n = Number(value);
  if (!isFinite(n)) return fallback;
  return Math.max(minValue, Math.min(maxValue, Math.floor(n)));
}

function flatCellFromParts(row, cell) {
  return (Number(row || 1) - 1) * CELLS_PER_ROW + Number(cell || 1);
}

function flatCellFromSlot(slot) {
  return flatCellFromParts(rowFromPosition(slot), cellFromPosition(slot));
}

function layoutConfig(location) {
  const out = {aisles:AISLES_PER_SHELF, cells:ROWS_PER_AISLE * CELLS_PER_ROW, slots:PINS_PER_CELL};
  const loc = clean(location);
  const rows = rackLabelRows();
  for (let i = 0; i < rows.length; i++) {
    if (clean(rows[i][0]) !== loc) continue;
    const kind = clean(rows[i][1]).toUpperCase();
    const value = Number(rows[i][5] || 0);
    if (kind === 'SO_DAY' && value > 0) out.aisles = clampInt(value, 1, AISLES_PER_SHELF, out.aisles);
    if (kind === 'SO_O' && value > 0) out.cells = clampInt(value, 1, ROWS_PER_AISLE * CELLS_PER_ROW, out.cells);
    if (kind === 'SO_PIN_O' && value > 0) out.slots = clampInt(value, 1, PINS_PER_CELL, out.slots);
  }
  out.capacity = out.aisles * out.cells * out.slots;
  return out;
}

function slotAllowedByLayout(location, slot, cfgOpt) {
  const cfg = cfgOpt || layoutConfig(location);
  const p = Number(slot || 0);
  if (p < 1 || p > CAPACITY) return false;
  return aisleFromPosition(p) <= cfg.aisles &&
    flatCellFromSlot(p) <= cfg.cells &&
    pinInCell(p) <= cfg.slots;
}

function allowedSlotsForLocation(location) {
  const cfg = layoutConfig(location);
  const out = [];
  for (let a = 1; a <= cfg.aisles; a++) {
    for (let flat = 1; flat <= cfg.cells; flat++) {
      const row = Math.floor((flat - 1) / CELLS_PER_ROW) + 1;
      const cell = ((flat - 1) % CELLS_PER_ROW) + 1;
      for (let pinNo = 1; pinNo <= cfg.slots; pinNo++) {
        out.push(slotFromParts(a, row, cell, pinNo));
      }
    }
  }
  return out;
}

function upsertRackLabelValue(location, kind, label, t) {
  const sheet = dataSheet(SHEET_RACK_LABELS);
  const rows = rackLabelRows();
  let foundRow = 0;
  for (let i = 0; i < rows.length; i++) {
    if (clean(rows[i][0]) === location && clean(rows[i][1]).toUpperCase() === kind &&
        Number(rows[i][2] || 0) === 0 && Number(rows[i][3] || 0) === 0 && Number(rows[i][4] || 0) === 0) {
      foundRow = i + 2;
      break;
    }
  }
  const values = [location, kind, 0, 0, 0, String(label), t];
  if (foundRow) sheet.getRange(foundRow, 1, 1, 7).setValues([values]);
  else sheet.appendRow(values);
}

function validateLayoutAgainstPins(location, cfg) {
  const pins = currentRows().filter(r => clean(r[1]) === location);
  for (let i = 0; i < pins.length; i++) {
    const slot = Number(pins[i][2] || 0);
    if (!slotAllowedByLayout(location, slot, cfg)) {
      return {ok:false, code:'layout_has_pins', message:'Không thể giảm cấu hình vì vị trí bị ẩn đang có PIN: ' + positionText(slot)};
    }
  }
  return {ok:true};
}

function saveLayoutConfig(req) {
  const location = clean(req.location);
  if (!location || !findLocation(location)) return {ok:false, code:'not_found', message:'Không tìm thấy Dãy.'};
  const cfg = {
    aisles:clampInt(req.aisles, 1, AISLES_PER_SHELF, AISLES_PER_SHELF),
    cells:clampInt(req.cells, 1, ROWS_PER_AISLE * CELLS_PER_ROW, ROWS_PER_AISLE * CELLS_PER_ROW),
    slots:clampInt(req.slots, 1, PINS_PER_CELL, PINS_PER_CELL)
  };
  cfg.capacity = cfg.aisles * cfg.cells * cfg.slots;
  const valid = validateLayoutAgainstPins(location, cfg);
  if (!valid.ok) return valid;
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const t = clean(req.clientTime) || nowText();
    upsertRackLabelValue(location, 'SO_DAY', cfg.aisles, t);
    upsertRackLabelValue(location, 'SO_O', cfg.cells, t);
    upsertRackLabelValue(location, 'SO_PIN_O', cfg.slots, t);
    const meta = findLocation(location);
    const occupied = countLocationPins(location);
    dataSheet(SHEET_VI_TRI).getRange(meta.row, 2, 1, 4).setValues([[cfg.capacity, occupied, Math.max(0, cfg.capacity - occupied), t]]);
    logUserAction(clean(req.operatorId), 'CAU_HINH_DAY', '', vehicleLabel() + ' • Dãy ' + Number(location || 0) + ' • ' + cfg.aisles + ' Kệ × ' + cfg.cells + ' Ô × ' + cfg.slots + ' Slot', clean(req.deviceId));
    if (!req._batchSync) SpreadsheetApp.flush();
    return {ok:true, location:location, layout:cfg};
  } finally { lock.releaseLock(); }
}

function rackLabelRows() {
  return rowsOf(dataSheet(SHEET_RACK_LABELS));
}

function deleteRackLabelsForLocation(location) {
  const sheet = dataSheet(SHEET_RACK_LABELS);
  const rows = rackLabelRows();
  for (let i = rows.length - 1; i >= 0; i--) {
    if (clean(rows[i][0]) === location) {
      sheet.deleteRow(i + 2);
    }
  }
}

function saveRackLabel(req) {
  const location = clean(req.location);
  const kind = clean(req.kind).toUpperCase();
  const aisle = Number(req.aisle || 0);
  const row = Number(req.row || 0);
  const cell = Number(req.cell || 0);
  const label = clean(req.label);

  if (!location || ['KE','DAY','HANG','O','SO_DAY','SO_HANG','SO_O','SO_PIN_O'].indexOf(kind) < 0 || !label) {
    return {ok:false, code:'bad_label', message:'Cấu hình / tên Kệ, Dãy, Hàng, Ô không hợp lệ.'};
  }
  if (!findLocation(location)) {
    return {ok:false, code:'not_found', message:'Không tìm thấy Kệ.'};
  }
  if (kind === 'SO_DAY' || kind === 'SO_HANG' || kind === 'SO_O' || kind === 'SO_PIN_O') {
    const value = Number(label || 0);
    const maxAllowed = kind === 'SO_DAY' ? AISLES_PER_SHELF : kind === 'SO_O' ? ROWS_PER_AISLE * CELLS_PER_ROW : kind === 'SO_PIN_O' ? PINS_PER_CELL : ROWS_PER_AISLE;
    if (value < 1 || value > maxAllowed) {
      return {ok:false, code:'bad_layout', message:
        kind === 'SO_DAY' ? 'Số Kệ phải từ 1 đến ' + AISLES_PER_SHELF + '.' : kind === 'SO_O' ? 'Số Ô/Kệ phải từ 1 đến ' + (ROWS_PER_AISLE * CELLS_PER_ROW) + '.' : kind === 'SO_PIN_O' ? 'Số Slot/Ô phải từ 1 đến ' + PINS_PER_CELL + '.' : 'Số Hàng phải từ 1 đến ' + ROWS_PER_AISLE + '.'};
    }
    const pins = currentRows().filter(r => clean(r[1]) === location);
    for (let i = 0; i < pins.length; i++) {
      const slot = Number(pins[i][2] || 0);
      if (kind === 'SO_DAY' && aisleFromPosition(slot) > value) {
        return {ok:false, code:'layout_has_pins', message:'Không thể giảm số Dãy vì Dãy bị ẩn đang có pin.'};
      }
      if (kind === 'SO_HANG' && rowFromPosition(slot) > value) {
        return {ok:false, code:'layout_has_pins', message:'Không thể giảm số Hàng vì Hàng bị ẩn đang có pin.'};
      }
      if (kind === 'SO_O' && flatCellFromSlot(slot) > value) {
        return {ok:false, code:'layout_has_pins', message:'Không thể giảm số Ô vì Ô bị ẩn đang có pin.'};
      }
      if (kind === 'SO_PIN_O' && pinInCell(slot) > value) {
        return {ok:false, code:'layout_has_pins', message:'Không thể giảm số Slot/Ô vì Slot bị ẩn đang có pin.'};
      }
    }
  } else if (kind !== 'KE') {
    if (aisle < 1 || aisle > AISLES_PER_SHELF) {
      return {ok:false, code:'bad_label', message:'Dãy không hợp lệ.'};
    }
    if (kind !== 'DAY' && (row < 1 || row > ROWS_PER_AISLE)) {
      return {ok:false, code:'bad_label', message:'Hàng không hợp lệ.'};
    }
    if (kind === 'O' && (cell < 1 || cell > CELLS_PER_ROW)) {
      return {ok:false, code:'bad_label', message:'Ô không hợp lệ.'};
    }
  }

  const sheet = dataSheet(SHEET_RACK_LABELS);
  const rows = rackLabelRows();
  const t = clean(req.clientTime) || nowText();
  let foundRow = 0;
  for (let i = 0; i < rows.length; i++) {
    if (clean(rows[i][0]) === location &&
        clean(rows[i][1]).toUpperCase() === kind &&
        Number(rows[i][2] || 0) === aisle &&
        Number(rows[i][3] || 0) === row &&
        Number(rows[i][4] || 0) === cell) {
      foundRow = i + 2;
      break;
    }
  }

  const values = [location, kind, aisle, row, cell, label, t];
  if (foundRow > 0) {
    sheet.getRange(foundRow, 1, 1, 7).setValues([values]);
  } else {
    sheet.appendRow(values);
  }
  if (['SO_DAY','SO_O','SO_PIN_O'].indexOf(kind) >= 0) {
    const cfg = layoutConfig(location);
    const meta = findLocation(location);
    const occupied = countLocationPins(location);
    if (meta) dataSheet(SHEET_VI_TRI).getRange(meta.row, 2, 1, 4).setValues([[cfg.capacity, occupied, Math.max(0, cfg.capacity - occupied), t]]);
  }

  logUserAction(
    clean(req.operatorId),
    'DOI_TEN_' + kind,
    '',
    vehicleLabel() + ' • Kệ ' + Number(location || 0) + ' • ' + label,
    clean(req.deviceId)
  );
  const historyAction =
    (kind === 'SO_DAY' || kind === 'SO_HANG') ? 'CAU_HINH_KE' : 'DOI_TEN_KE';
  const historyNote =
    kind === 'SO_DAY'
      ? 'Đổi số lượng Dãy của Kệ thành ' + label
      : kind === 'SO_HANG'
        ? 'Đổi số lượng Hàng/Dãy của Kệ thành ' + label
        : 'Đổi tên ' + kind + ' thành "' + label + '"';
  logHistory(
    '', historyAction, location, 0, historyNote,
    clean(req.deviceId),
    clean(req.operatorId),
    t
  );
  return {ok:true, label:label, vehicleType:WAREHOUSE_ID};
}

function listLocations() {
  const result = locationRows().map(r => ({
    location:clean(r[0]),
    occupied:Number(r[2] || 0)
  }));
  result.sort((a, b) => naturalCompare(a.location, b.location));
  return {ok:true, locations:result};
}

function getLocation(req) {
  const location = clean(req.location);
  if (!findLocation(location)) {
    return {ok:false, code:'not_found', message:'Không tìm thấy Dãy số ' + Number(location || 0) + '.'};
  }

  const slots = [];
  for (let i = 1; i <= CAPACITY; i++) {
    slots.push({slot:i, pinCode:null, storedAt:null});
  }

  let occupied = 0;
  currentRows().forEach(r => {
    if (clean(r[1]) !== location) return;
    const slot = Number(r[2]);
    if (slot < 1 || slot > CAPACITY) return;
    slots[slot - 1] = {
      slot:slot,
      pinCode:String(r[0] || ''),
      storedAt:String(r[3] || ''),
      pinType:String(r[7] || '')
    };
    occupied++;
  });

  return {
    ok:true,
    location:location,
    occupied:occupied,
    slots:slots
  };
}

function importPinToCell(req) {
  const location = clean(req.location);
  const code = clean(req.code);
  const deviceId = clean(req.deviceId);
  const operatorId = clean(req.operatorId);
  const aisle = Number(req.aisle || 0);
  const row = Number(req.row || 0);
  const cell = Number(req.cell || 0);
  const preferredSlot = Number(req.preferredSlot || 0);
  const requestedPinType = pinTypeText(req.pinType);

  if (requestedPinType.length > 80) {
    return {ok:false, code:'bad_pin_type', message:'Loại pin tối đa 80 ký tự.'};
  }
  if (!location || !code) {
    return {ok:false, code:'bad_input', message:'Thiếu Kệ hoặc mã QR/Text.'};
  }
  const cfg = layoutConfig(location);
  const flatCell = flatCellFromParts(row, cell);
  if (aisle < 1 || aisle > cfg.aisles || row < 1 || row > ROWS_PER_AISLE || cell < 1 || cell > CELLS_PER_ROW || flatCell > cfg.cells) {
    return {ok:false, code:'bad_cell', message:'Kệ / Ô nằm ngoài cấu hình của Dãy.'};
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const duplicate = findCurrentPin(code);
    if (duplicate) {
      return {
        ok:false,
        code:'duplicate',
        message:'MÃ ĐÃ TỒN TẠI - Kệ số ' + Number(duplicate.location || 0) +
          ' - ' + positionText(duplicate.slot),
        location:duplicate.location,
        slot:duplicate.slot
      };
    }

    if (!findLocation(location)) {
      return {ok:false, code:'not_found', message:'Không tìm thấy Kệ.'};
    }

    const allowedSlots = cellSlotNumbers(aisle, row, cell).slice(0, cfg.slots);
    const allowed = {};
    allowedSlots.forEach(s => allowed[s] = true);
    const occupied = {};
    currentLocationPairs(location).forEach(r => {
      const slot = Number(r.slot || 0);
      if (allowed[slot]) occupied[slot] = r.code || true;
    });

    let slot = null;
    if (allowed[preferredSlot] && !occupied[preferredSlot]) {
      slot = preferredSlot;
    }
    if (slot === null) {
      for (let i = 0; i < allowedSlots.length; i++) {
        const candidate = allowedSlots[i];
        if (!occupied[candidate]) {
          slot = candidate;
          break;
        }
      }
    }
    if (slot === null) {
      return {ok:false, code:'cell_full', message:'Ô đã đầy ' + cfg.slots + '/' + cfg.slots + ' pin. Hãy chọn Ô khác.'};
    }

    const t = clean(req.clientTime) || nowText();
    const pinType = ensurePinType(requestedPinType, operatorId);
    dataSheet(SHEET_TON).appendRow([
      code, location, slot, t, t, deviceId, operatorId, pinType
    ]);
    logHistory(
      code, 'NHAP', location, slot,
      'Nhập pin vào ' + positionText(slot),
      deviceId, operatorId, t, pinType
    );

    if (!req._batchSync) adjustLocationStats(location, 1);

    return {
      ok:true,
      code:code,
      location:location,
      slot:slot,
      pinType:pinType,
      vehicleType:WAREHOUSE_ID,
      cellFull:Object.keys(occupied).length + 1 >= cfg.slots
    };
  } finally {
    lock.releaseLock();
  }
}

function importPin(req, exactSlot) {
  const location = clean(req.location);
  const code = clean(req.code);
  const deviceId = clean(req.deviceId);
  const operatorId = clean(req.operatorId);
  const requestedPinType = pinTypeText(req.pinType);

  if (requestedPinType.length > 80) {
    return {ok:false, code:'bad_pin_type', message:'Loại pin tối đa 80 ký tự.'};
  }
  if (!location || !code) {
    return {ok:false, code:'bad_input', message:'Thiếu Kệ hoặc mã QR/Text.'};
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    if (!findLocation(location)) {
      return {ok:false, code:'not_found', message:'Không tìm thấy Dãy số ' + Number(location || 0) + '.'};
    }

    const duplicate = findCurrentPin(code);
    if (duplicate) {
      return {
        ok:false,
        code:'duplicate',
        message:'MÃ ĐÃ TỒN TẠI - Kệ số ' + Number(duplicate.location || 0) +
          ' - ' + positionText(duplicate.slot),
        location:duplicate.location,
        slot:duplicate.slot
      };
    }

    const occupiedSlots = {};
    currentLocationPairs(location).forEach(r => {
      occupiedSlots[Number(r.slot)] = r.code || true;
    });

    const cfg = layoutConfig(location);
    const allowedList = allowedSlotsForLocation(location);
    const allowedMap = {};
    allowedList.forEach(v => allowedMap[v] = true);
    let slot = exactSlot;

    if (slot !== null && slot !== undefined && !isNaN(slot)) {
      slot = Number(slot);
      if (!allowedMap[slot]) {
        return {ok:false, code:'bad_slot', message:'Vị trí nằm ngoài cấu hình của Dãy.'};
      }
      if (occupiedSlots[slot]) {
        return {
          ok:false,
          code:'occupied',
          message:positionText(slot) + ' đang có pin ' + occupiedSlots[slot] + '.'
        };
      }
    } else {
      slot = null;
      for (let i = 0; i < allowedList.length; i++) {
        if (!occupiedSlots[allowedList[i]]) { slot = allowedList[i]; break; }
      }
      if (slot === null) return {ok:false, code:'full', message:'Dãy số ' + Number(location || 0) + ' đã đầy ' + cfg.capacity + '/' + cfg.capacity + '.'};
    }

    const t = nowText();
    const pinType = ensurePinType(requestedPinType, operatorId);
    dataSheet(SHEET_TON).appendRow([
      code, location, slot, t, t, deviceId, operatorId, pinType
    ]);

    logHistory(
      code, 'NHAP', location, slot,
      'Nhập pin vào kho', deviceId, operatorId, clean(req.clientTime), pinType
    );

    if (!req._batchSync) adjustLocationStats(location, 1);

    const occupiedAfter = Object.keys(occupiedSlots).length + 1;
    return {
      ok:true,
      code:code,
      location:location,
      slot:slot,
      pinType:pinType,
      vehicleType:WAREHOUSE_ID,
      full:occupiedAfter >= cfg.capacity
    };
  } finally {
    lock.releaseLock();
  }
}

function exportPin(req) {
  const code = clean(req.code);
  const deviceId = clean(req.deviceId);
  const operatorId = clean(req.operatorId);

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const found = findCurrentPin(code);
    if (!found) {
      return {ok:false, code:'not_found', message:'Pin không còn trong tồn hiện tại.'};
    }

    const expectedLocation = clean(req.expectedLocation);
    const expectedSlot = Number(req.expectedSlot || 0);
    if (expectedLocation &&
        (found.location !== expectedLocation ||
         (expectedSlot > 0 && found.slot !== expectedSlot))) {
      return {
        ok:false,
        code:'state_conflict',
        message:'Dữ liệu đã thay đổi trên thiết bị khác. Pin hiện ở Kệ số ' +
          Number(found.location || 0) + ' - ' + positionText(found.slot) + '.'
      };
    }

    dataSheet(SHEET_TON).deleteRow(found.row);
    logHistory(
      code, 'XUAT', found.location, found.slot,
      'Xuất pin khỏi kho', deviceId, operatorId, clean(req.clientTime), found.pinType
    );
    if (!req._batchSync) adjustLocationStats(found.location, -1);

    return {
      ok:true,
      code:code,
      location:found.location,
      slot:found.slot,
      pinType:found.pinType || '',
      vehicleType:WAREHOUSE_ID
    };
  } finally {
    lock.releaseLock();
  }
}

function exportSlot(req) {
  const location = clean(req.location);
  const slot = Number(req.slot);
  const deviceId = clean(req.deviceId);
  const operatorId = clean(req.operatorId);

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const found = findCurrentAt(location, slot);
    if (!found) {
      return {ok:false, code:'empty', message:'Ô đang trống.'};
    }

    dataSheet(SHEET_TON).deleteRow(found.row);
    logHistory(
      found.code, 'XUAT', location, slot,
      'Xuất pin khỏi ô', deviceId, operatorId, clean(req.clientTime), found.pinType
    );
    if (!req._batchSync) adjustLocationStats(location, -1);
    return {ok:true, code:found.code, location:location, slot:slot, pinType:found.pinType || '', vehicleType:WAREHOUSE_ID};
  } finally {
    lock.releaseLock();
  }
}

function replacePin(req) {
  const location = clean(req.location);
  const slot = Number(req.slot);
  const newCode = clean(req.newCode);
  const deviceId = clean(req.deviceId);
  const operatorId = clean(req.operatorId);
  const requestedPinType = pinTypeText(req.pinType);

  if (requestedPinType.length > 80) {
    return {ok:false, code:'bad_pin_type', message:'Loại pin tối đa 80 ký tự.'};
  }
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const duplicate = findCurrentPin(newCode);
    if (duplicate) {
      return {
        ok:false,
        code:'duplicate',
        message:'MÃ ĐÃ TỒN TẠI - Kệ số ' + Number(duplicate.location || 0) +
          ' - ' + positionText(duplicate.slot),
        location:duplicate.location,
        slot:duplicate.slot
      };
    }

    const old = findCurrentAt(location, slot);
    const hasExpectedOldCode = Object.prototype.hasOwnProperty.call(req, 'expectedOldCode');
    const expectedOldCode = clean(req.expectedOldCode);
    const actualOldCode = old ? clean(old.code) : '';
    if (hasExpectedOldCode && actualOldCode !== expectedOldCode) {
      return {
        ok:false,
        code:'state_conflict',
        message:positionText(slot) +
          ' đã thay đổi trên thiết bị khác. Hãy đồng bộ và kiểm tra lại.'
      };
    }

    const sheet = dataSheet(SHEET_TON);
    const t = nowText();

    if (old) {
      sheet.deleteRow(old.row);
      logHistory(
        old.code, 'THAY_XUAT', location, slot,
        'Thay pin - xuất pin cũ', deviceId, operatorId, clean(req.clientTime), old.pinType
      );
    }

    const pinType = ensurePinType(requestedPinType, operatorId);
    sheet.appendRow([
      newCode, location, slot, t, t, deviceId, operatorId, pinType
    ]);
    logHistory(
      newCode, 'THAY_NHAP', location, slot,
      'Thay pin - nhập pin mới', deviceId, operatorId, clean(req.clientTime), pinType
    );

    // Replace keeps the occupied count unchanged. Avoid a full inventory scan.
    return {
      ok:true,
      code:newCode,
      location:location,
      slot:slot,
      pinType:pinType,
      vehicleType:WAREHOUSE_ID
    };
  } finally {
    lock.releaseLock();
  }
}

function searchPin(req) {
  const code = clean(req.code);
  if (!code) {
    return {ok:false, code:'bad_code', message:'Mã pin trống.'};
  }

  const current = findCurrentPin(code);
  if (current) {
    return {
      ok:true, found:true, active:true, code:code,
      location:current.location, slot:current.slot,
      storedAt:current.storedAt, exportedAt:'', pinType:current.pinType || '',
      vehicleType:WAREHOUSE_ID, lookup:'FAST_INDEX'
    };
  }

  const rows = historyRowsForCode(code);
  let latest = null;
  let storedAt = '';
  let exportedAt = '';
  let pinType = '';

  for (let i = rows.length - 1; i >= 0; i--) {
    const r = rows[i];
    if (!latest) {
      pinType = String(r[8] || '');
      latest = {location:clean(r[3]), slot:Number(r[4] || 0)};
    }
    const action = clean(r[2]);
    if (!exportedAt && (action === 'XUAT' || action === 'THAY_XUAT')) exportedAt = String(r[0] || '');
    if (!storedAt && (action === 'NHAP' || action === 'THAY_NHAP')) storedAt = String(r[0] || '');
    if (storedAt && exportedAt) break;
  }

  if (!latest) {
    return {ok:true, found:false, active:false, code:code, location:'', slot:0, storedAt:'', exportedAt:'', pinType:'', vehicleType:WAREHOUSE_ID, lookup:'FAST_INDEX'};
  }

  return {
    ok:true, found:true, active:false, code:code,
    location:latest.location, slot:latest.slot,
    storedAt:storedAt, exportedAt:exportedAt, pinType:pinType,
    vehicleType:WAREHOUSE_ID, lookup:'FAST_INDEX'
  };
}

function recentHistory(req) {
  const limit = Math.max(1, Math.min(500, Number(req.limit || 200)));
  const sheet = dataSheet(SHEET_LS);
  const lastRow = sheet.getLastRow();
  const lastCol = sheet.getLastColumn();
  if (lastRow < 2 || lastCol < 1) return {ok:true, history:[]};
  const count = Math.min(limit, lastRow - 1);
  const startRow = lastRow - count + 1;
  const rows = sheet.getRange(startRow, 1, count, lastCol).getValues();
  const result = [];
  for (let i = rows.length - 1; i >= 0; i--) {
    const r = rows[i];
    result.push({
      timestamp:String(r[0] || ''),
      pinCode:String(r[1] || ''),
      action:String(r[2] || ''),
      location:String(r[3] || ''),
      slot:Number(r[4] || 0),
      note:String(r[5] || ''),
      deviceId:String(r[6] || ''),
      operatorId:String(r[7] || ''),
      pinType:String(r[8] || '')
    });
  }
  return {ok:true, history:result, vehicleType:WAREHOUSE_ID};
}

function saveAudit(req) {
  const scanned = parseJsonArray(req.scanned);
  const missing = parseJsonArray(req.missing);
  const wrongLocation = parseJsonArray(req.wrongLocation);
  const unknown = parseJsonArray(req.unknown);

  const details = JSON.stringify({
    scanned:scanned,
    missing:missing,
    wrongLocation:wrongLocation,
    unknown:unknown
  });

  const auditTime = clean(req.clientTime) || nowText();
  dataSheet(SHEET_KK).appendRow([
    auditTime,
    clean(req.sessionId),
    clean(req.location),
    Number(req.expected || 0),
    scanned.length,
    Number(req.matched || 0),
    missing.length,
    wrongLocation.length,
    unknown.length,
    Number(req.duplicateScans || 0),
    details,
    clean(req.operatorId)
  ]);
  const auditLocation = clean(req.location);
  const isWholeWarehouse = clean(req.scope).toUpperCase() === 'ALL' || auditLocation.toUpperCase() === 'ALL';
  logHistory(
    '', 'KIEM_KE', isWholeWarehouse ? 'ALL' : auditLocation, 0,
    (isWholeWarehouse ? 'Kiểm kê TOÀN KHO ' : 'Kiểm kê ') + scanned.length +
      ' mã • khớp ' + Number(req.matched || 0) +
      ' • thiếu ' + missing.length +
      (isWholeWarehouse ? '' : ' • sai Kệ ' + wrongLocation.length),
    clean(req.deviceId),
    clean(req.operatorId),
    auditTime
  );

  if (!req._batchSync) SpreadsheetApp.flush();
  return {ok:true};
}

function exportData() {
  refreshAllLocationStats();

  const inventory = currentRows().map(r => ({
    code:String(r[0] || ''),
    location:String(r[1] || ''),
    slot:Number(r[2] || 0),
    row:rowFromPosition(Number(r[2] || 0)),
    cell:cellFromPosition(Number(r[2] || 0)),
    pinInCell:pinInCell(Number(r[2] || 0)),
    storedAt:String(r[3] || ''),
    updatedAt:String(r[4] || ''),
    deviceId:String(r[5] || ''),
    operatorId:String(r[6] || ''),
    pinType:String(r[7] || '')
  }));

  const locations = locationRows().map(r => ({
    location:String(r[0] || ''),
    capacity:Number(r[1] || CAPACITY),
    occupied:Number(r[2] || 0),
    empty:Number(r[3] || 0),
    updatedAt:String(r[4] || '')
  }));

  const history = historyRows().map(r => ({
    timestamp:String(r[0] || ''),
    code:String(r[1] || ''),
    action:String(r[2] || ''),
    location:String(r[3] || ''),
    slot:Number(r[4] || 0),
    row:rowFromPosition(Number(r[4] || 0)),
    cell:cellFromPosition(Number(r[4] || 0)),
    pinInCell:pinInCell(Number(r[4] || 0)),
    note:String(r[5] || ''),
    deviceId:String(r[6] || ''),
    operatorId:String(r[7] || ''),
    pinType:String(r[8] || '')
  }));

  const audits = rowsOf(dataSheet(SHEET_KK)).map(r => ({
    timestamp:String(r[0] || ''),
    sessionId:String(r[1] || ''),
    location:String(r[2] || ''),
    expected:Number(r[3] || 0),
    scanned:Number(r[4] || 0),
    matched:Number(r[5] || 0),
    missingCount:Number(r[6] || 0),
    wrongLocationCount:Number(r[7] || 0),
    unknownCount:Number(r[8] || 0),
    duplicateScans:Number(r[9] || 0),
    details:String(r[10] || ''),
    operatorId:String(r[11] || '')
  }));

  const rackLabels = rackLabelRows().map(r => ({
    location:clean(r[0]),
    kind:clean(r[1]),
    aisle:Number(r[2] || 0),
    row:Number(r[3] || 0),
    cell:Number(r[4] || 0),
    label:String(r[5] || ''),
    updatedAt:String(r[6] || '')
  }));

  return {
    ok:true,
    inventory:inventory,
    locations:locations,
    history:history,
    audits:audits,
    rackLabels:rackLabels,
    pinTypes:listPinTypes(),
    vehicleType:WAREHOUSE_ID
  };
}

// PC-linked range export. Legacy VinFast E2W Android clients keep using exportData unchanged.
// Supported: mode=day&date=YYYY-MM-DD, mode=month&month=YYYY-MM, or
// from=YYYY-MM-DD&to=YYYY-MM-DD (to is inclusive).
function exportDataRange(req) {
  const all = exportData();
  const range = exportRangeBounds(req || {});
  if (!range.ok) return range;

  const history = all.history.filter(x => inExportRange(x.timestamp, range));
  const audits = all.audits.filter(x => inExportRange(x.timestamp, range));

  return {
    ok:true,
    mode:range.mode,
    from:range.fromText,
    to:range.toText,
    serverTime:nowText(),
    // Inventory and locations intentionally represent CURRENT stock.
    inventory:all.inventory,
    locations:all.locations,
    history:history,
    audits:audits,
    rackLabels:all.rackLabels || [],
    pinTypes:all.pinTypes || [],
    vehicleType:WAREHOUSE_ID
  };
}

function exportRangeBounds(req) {
  const mode = clean(req.mode).toLowerCase();
  if (!mode || mode === 'all') {
    return {ok:true, mode:'all', from:null, toExclusive:null, fromText:'', toText:''};
  }

  if (mode === 'day') {
    const d = parseIsoDate(clean(req.date));
    if (!d) return {ok:false, code:'bad_date', message:'Ngày xuất không hợp lệ. Dùng YYYY-MM-DD.'};
    return {ok:true, mode:'day', from:d, toExclusive:addDays(d, 1), fromText:clean(req.date), toText:clean(req.date)};
  }

  if (mode === 'month') {
    const m = /^(\d{4})-(\d{2})$/.exec(clean(req.month));
    if (!m) return {ok:false, code:'bad_month', message:'Tháng xuất không hợp lệ. Dùng YYYY-MM.'};
    const year = Number(m[1]);
    const month = Number(m[2]);
    if (month < 1 || month > 12) return {ok:false, code:'bad_month', message:'Tháng xuất không hợp lệ.'};
    const start = new Date(year, month - 1, 1, 0, 0, 0, 0);
    const end = new Date(year, month, 1, 0, 0, 0, 0);
    return {ok:true, mode:'month', from:start, toExclusive:end, fromText:clean(req.month) + '-01', toText:clean(req.month)};
  }

  if (mode === 'range') {
    const start = parseIsoDate(clean(req.from));
    const end = parseIsoDate(clean(req.to));
    if (!start || !end || end.getTime() < start.getTime()) {
      return {ok:false, code:'bad_range', message:'Khoảng ngày không hợp lệ.'};
    }
    return {ok:true, mode:'range', from:start, toExclusive:addDays(end, 1), fromText:clean(req.from), toText:clean(req.to)};
  }

  return {ok:false, code:'bad_mode', message:'Chế độ lọc Excel không hợp lệ.'};
}

function parseIsoDate(text) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text || '');
  if (!m) return null;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), 0, 0, 0, 0);
  if (d.getFullYear() !== Number(m[1]) || d.getMonth() !== Number(m[2]) - 1 || d.getDate() !== Number(m[3])) return null;
  return d;
}

function addDays(date, days) {
  const d = new Date(date.getTime());
  d.setDate(d.getDate() + Number(days || 0));
  return d;
}

function inExportRange(text, range) {
  if (!range.from) return true;
  const d = parseN07DateForExport(String(text || ''));
  return !!d && d.getTime() >= range.from.getTime() && d.getTime() < range.toExclusive.getTime();
}

function parseN07DateForExport(text) {
  let m = /^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})(?:\s+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?/.exec(text);
  if (m) return new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]), Number(m[4] || 0), Number(m[5] || 0), Number(m[6] || 0));
  const iso = new Date(text);
  return isNaN(iso.getTime()) ? null : iso;
}

function findLocation(location) {
  const rows = locationRows();
  for (let i = 0; i < rows.length; i++) {
    if (clean(rows[i][0]) === location) {
      return {row:i + 2, location:location};
    }
  }
  return null;
}

function exactRowsByText(sheet, column, text) {
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];
  const target = clean(text);
  if (!target) return [];
  try {
    const matches = sheet.getRange(2, column, lastRow - 1, 1)
      .createTextFinder(target)
      .matchEntireCell(true)
      .matchCase(true)
      .findAll();
    return matches.map(r => r.getRow()).sort((a,b) => a-b);
  } catch (_) {
    return [];
  }
}

function historyRowsForCode(code) {
  const sheet = dataSheet(SHEET_LS);
  const rowNums = exactRowsByText(sheet, 2, code);
  if (!rowNums.length) return [];
  const lastCol = sheet.getLastColumn();
  return rowNums.map(row => sheet.getRange(row, 1, 1, lastCol).getValues()[0]);
}

function currentLocationPairs(location) {
  const sheet = dataSheet(SHEET_TON);
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];
  const values = sheet.getRange(2, 1, lastRow - 1, 3).getValues();
  const out = [];
  for (let i = 0; i < values.length; i++) {
    if (clean(values[i][1]) === location) out.push({code:String(values[i][0] || ''), slot:Number(values[i][2] || 0), row:i + 2});
  }
  return out;
}

function findCurrentPin(code) {
  const sheet = dataSheet(SHEET_TON);
  const rowNums = exactRowsByText(sheet, 1, code);
  if (!rowNums.length) return null;
  const row = rowNums[rowNums.length - 1];
  const r = sheet.getRange(row, 1, 1, Math.max(8, sheet.getLastColumn())).getValues()[0];
  return {
    row:row,
    code:String(r[0] || ''),
    location:clean(r[1]),
    slot:Number(r[2]),
    storedAt:String(r[3] || ''),
    pinType:String(r[7] || '')
  };
}

function findCurrentAt(location, slot) {
  const sheet = dataSheet(SHEET_TON);
  const pairs = currentLocationPairs(location);
  for (let i = pairs.length - 1; i >= 0; i--) {
    if (Number(pairs[i].slot) !== Number(slot)) continue;
    const r = sheet.getRange(pairs[i].row, 1, 1, Math.max(8, sheet.getLastColumn())).getValues()[0];
    return {
      row:pairs[i].row,
      code:String(r[0] || ''),
      location:location,
      slot:Number(r[2]),
      storedAt:String(r[3] || ''),
      pinType:String(r[7] || '')
    };
  }
  return null;
}

function countLocationPins(location) {
  return currentLocationPairs(location).length;
}

function updateLocationStats(location) {
  const meta = findLocation(location);
  if (!meta) return;
  const occupied = countLocationPins(location);
  dataSheet(SHEET_VI_TRI)
    .getRange(meta.row, 2, 1, 4)
    .setValues([[CAPACITY, occupied, CAPACITY - occupied, nowText()]]);
}

function adjustLocationStats(location, delta) {
  const meta = findLocation(location);
  if (!meta) return;
  const sheet = dataSheet(SHEET_VI_TRI);
  const row = sheet.getRange(meta.row, 2, 1, 3).getValues()[0];
  const capacity = Number(row[0] || CAPACITY) || CAPACITY;
  let occupied = Number(row[1] || 0) + Number(delta || 0);
  occupied = Math.max(0, Math.min(capacity, occupied));
  sheet.getRange(meta.row, 2, 1, 4).setValues([[capacity, occupied, capacity - occupied, nowText()]]);
}

function rebuildLocationStatsFast() {
  const locationSheet = dataSheet(SHEET_VI_TRI);
  const locations = locationRows();
  if (locations.length === 0) return;

  const counts = {};
  currentRows().forEach(r => {
    const location = clean(r[1]);
    if (location) counts[location] = (counts[location] || 0) + 1;
  });

  const t = nowText();
  const values = locations.map(r => {
    const location = clean(r[0]);
    const occupied = counts[location] || 0;
    return [CAPACITY, occupied, CAPACITY - occupied, t];
  });

  locationSheet.getRange(2, 2, values.length, 4).setValues(values);
}

function refreshAllLocationStats() {
  rebuildLocationStatsFast();
}



// ===== V25 BATCH UPLOAD =====
// One HTTP request may contain up to 50 rows. High-volume Import/Export use
// setValues()/grouped deleteRows() so scanner sessions do not upload row-by-row.
const N07_BATCH_MAX = 50;

function n07BatchItems(req) {
  const items = parseJsonArray(req.items);
  if (items.length < 1) return {ok:false, code:'batch_empty', message:'Batch đang trống.'};
  if (items.length > N07_BATCH_MAX) return {ok:false, code:'batch_too_large', message:'Mỗi batch tối đa ' + N07_BATCH_MAX + ' dòng.'};
  return {ok:true, items:items};
}

function n07ResultError(index, item, code, message, extra) {
  const out = {index:index, clientId:item && item.clientId !== undefined ? item.clientId : '', ok:false, code:code, message:message};
  if (extra) Object.keys(extra).forEach(k => out[k] = extra[k]);
  return out;
}

function n07ResultOk(index, item, data) {
  const out = {index:index, clientId:item && item.clientId !== undefined ? item.clientId : '', ok:true};
  if (data) Object.keys(data).forEach(k => out[k] = data[k]);
  return out;
}

function ensurePinTypesBatch(values, operatorId) {
  const wanted = [];
  const seenWanted = {};
  (values || []).forEach(v => {
    const text = pinTypeText(v);
    const key = text.toLowerCase();
    if (text && !seenWanted[key]) { seenWanted[key] = true; wanted.push(text); }
  });
  const canonical = {};
  const rows = pinTypeRows();
  rows.forEach(r => {
    const vehicle = normalizeWarehouseRequest(r[0]);
    const text = clean(r[1]);
    if ((!vehicle || vehicle === ACTIVE_VEHICLE) && text) canonical[text.toLowerCase()] = text;
  });
  const add = [];
  const now = nowText();
  wanted.forEach(text => {
    const key = text.toLowerCase();
    if (!canonical[key]) {
      canonical[key] = text;
      add.push([ACTIVE_VEHICLE, text, now, clean(operatorId), true]);
    }
  });
  if (add.length) {
    const sh = ss().getSheetByName(SHEET_PIN_TYPES);
    sh.getRange(sh.getLastRow() + 1, 1, add.length, 5).setValues(add);
  }
  return canonical;
}

function applyLocationDeltasBatch(deltas) {
  const sh = dataSheet(SHEET_VI_TRI);
  const rows = locationRows();
  if (!rows.length) return;
  const t = nowText();
  const vals = rows.map(r => {
    const loc = clean(r[0]);
    const cfg = layoutConfig(loc);
    const capacity = cfg.capacity;
    let occupied = Number(r[2] || 0) + Number((deltas || {})[loc] || 0);
    occupied = Math.max(0, Math.min(capacity, occupied));
    return [capacity, occupied, Math.max(0, capacity - occupied), t];
  });
  sh.getRange(2, 2, vals.length, 4).setValues(vals);
}

function batchImportPins(req) {
  const parsed = n07BatchItems(req);
  if (!parsed.ok) return parsed;
  const items = parsed.items;
  const operatorId = clean(req.operatorId);
  const deviceId = clean(req.deviceId);
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const locExists = {};
    locationRows().forEach(r => { const id = clean(r[0]); if (id) locExists[id] = true; });
    const current = currentRows();
    const existingCodes = {};
    const occupiedByLocation = {};
    current.forEach(r => {
      const code = clean(r[0]).toUpperCase();
      const loc = clean(r[1]);
      const slot = Number(r[2] || 0);
      if (code) existingCodes[code] = {location:loc, slot:slot};
      if (!occupiedByLocation[loc]) occupiedByLocation[loc] = {};
      if (slot) occupiedByLocation[loc][slot] = clean(r[0]) || true;
    });
    const cfgCache = {};
    const accepted = [];
    const results = Array(items.length);
    const deltas = {};

    items.forEach((item, index) => {
      const location = clean(item.location);
      const code = clean(item.code);
      const requestedPinType = pinTypeText(item.pinType);
      if (!location || !code) { results[index] = n07ResultError(index,item,'bad_input','Thiếu Dãy hoặc mã PIN.'); return; }
      if (requestedPinType.length > 80) { results[index] = n07ResultError(index,item,'bad_pin_type','Loại pin tối đa 80 ký tự.'); return; }
      if (!locExists[location]) { results[index] = n07ResultError(index,item,'not_found','Không tìm thấy Dãy số ' + Number(location || 0) + '.'); return; }
      const upper = code.toUpperCase();
      if (existingCodes[upper]) {
        const d = existingCodes[upper];
        results[index] = n07ResultError(index,item,'duplicate','MÃ ĐÃ TỒN TẠI - Dãy ' + Number(d.location || 0) + ' - ' + positionText(d.slot),d);
        return;
      }
      const aisle = Number(item.aisle || 0), row = Number(item.row || 0), cell = Number(item.cell || 0);
      const cfg = cfgCache[location] || (cfgCache[location] = layoutConfig(location));
      const flatCell = flatCellFromParts(row, cell);
      if (aisle < 1 || aisle > cfg.aisles || row < 1 || row > ROWS_PER_AISLE || cell < 1 || cell > CELLS_PER_ROW || flatCell > cfg.cells) {
        results[index] = n07ResultError(index,item,'bad_cell','Kệ / Ô / Vị trí nằm ngoài cấu hình của Dãy.'); return;
      }
      const allowedSlots = cellSlotNumbers(aisle,row,cell).slice(0,cfg.slots);
      const allowed = {}; allowedSlots.forEach(s => allowed[s] = true);
      const occ = occupiedByLocation[location] || (occupiedByLocation[location] = {});
      let slot = Number(item.preferredSlot || 0);
      if (!allowed[slot] || occ[slot]) slot = 0;
      if (!slot) {
        for (let i=0;i<allowedSlots.length;i++) if (!occ[allowedSlots[i]]) { slot = allowedSlots[i]; break; }
      }
      if (!slot) { results[index] = n07ResultError(index,item,'cell_full','Ô / Vị trí đã đầy ' + cfg.slots + '/' + cfg.slots + ' PIN.'); return; }
      occ[slot] = code;
      existingCodes[upper] = {location:location,slot:slot};
      accepted.push({index:index,item:item,location:location,code:code,slot:slot,pinType:requestedPinType,clientTime:clean(item.clientTime) || nowText()});
      deltas[location] = Number(deltas[location] || 0) + 1;
    });

    const typeMap = ensurePinTypesBatch(accepted.map(x => x.pinType), operatorId);
    const tonRows = [], hisRows = [];
    accepted.forEach(x => {
      const pinType = x.pinType ? (typeMap[x.pinType.toLowerCase()] || x.pinType) : '';
      const t = x.clientTime || nowText();
      tonRows.push([x.code,x.location,x.slot,t,t,deviceId,operatorId,pinType]);
      hisRows.push([t,x.code,'NHAP',x.location,x.slot,'Nhập pin vào ' + positionText(x.slot),deviceId,operatorId,pinType]);
      results[x.index] = n07ResultOk(x.index,x.item,{code:x.code,location:x.location,slot:x.slot,pinType:pinType});
    });
    if (tonRows.length) {
      const sh = dataSheet(SHEET_TON);
      sh.getRange(sh.getLastRow()+1,1,tonRows.length,8).setValues(tonRows);
      const hs = dataSheet(SHEET_LS);
      hs.getRange(hs.getLastRow()+1,1,hisRows.length,9).setValues(hisRows);
      applyLocationDeltasBatch(deltas);
      SpreadsheetApp.flush();
    }
    return {ok:true, count:items.length, success:accepted.length, failed:items.length-accepted.length, results:results};
  } finally { lock.releaseLock(); }
}

function n07DeleteSheetRowsGrouped(sheet, sheetRows) {
  const nums = Array.from(new Set((sheetRows || []).map(Number).filter(v => v >= 2))).sort((a,b)=>a-b);
  if (!nums.length) return;
  const groups = [];
  let start=nums[0], prev=nums[0];
  for (let i=1;i<nums.length;i++) {
    if (nums[i] === prev + 1) { prev = nums[i]; continue; }
    groups.push([start,prev]); start=prev=nums[i];
  }
  groups.push([start,prev]);
  for (let i=groups.length-1;i>=0;i--) sheet.deleteRows(groups[i][0], groups[i][1]-groups[i][0]+1);
}

function batchExportPins(req) {
  const parsed = n07BatchItems(req);
  if (!parsed.ok) return parsed;
  const items = parsed.items;
  const operatorId = clean(req.operatorId), deviceId = clean(req.deviceId);
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const rows = currentRows();
    const byCode = {};
    rows.forEach((r,i) => {
      const code = clean(r[0]);
      if (code) byCode[code.toUpperCase()] = {row:i+2, code:code, location:clean(r[1]), slot:Number(r[2]||0), storedAt:String(r[3]||''), pinType:String(r[7]||'')};
    });
    const seen = {}, results = Array(items.length), success = [], deleteRows = [], histRows = [], deltas = {};
    items.forEach((item,index) => {
      const code = clean(item.code), upper = code.toUpperCase();
      if (!code) { results[index]=n07ResultError(index,item,'bad_code','Mã PIN trống.'); return; }
      if (seen[upper]) { results[index]=n07ResultError(index,item,'duplicate_batch','Mã PIN bị trùng trong batch.'); return; }
      seen[upper]=true;
      const found = byCode[upper];
      if (!found) { results[index]=n07ResultError(index,item,'not_found','PIN không còn trong tồn hiện tại.'); return; }
      const expectedLocation = clean(item.expectedLocation), expectedSlot = Number(item.expectedSlot||0);
      if (expectedLocation && (found.location !== expectedLocation || (expectedSlot>0 && found.slot !== expectedSlot))) {
        results[index]=n07ResultError(index,item,'state_conflict','Dữ liệu đã thay đổi trên thiết bị khác. PIN hiện ở Dãy ' + Number(found.location||0) + ' - ' + positionText(found.slot),{location:found.location,slot:found.slot}); return;
      }
      const t = clean(item.clientTime) || nowText();
      deleteRows.push(found.row);
      histRows.push([t,found.code,'XUAT',found.location,found.slot,'Xuất pin khỏi kho',deviceId,operatorId,found.pinType]);
      deltas[found.location] = Number(deltas[found.location] || 0) - 1;
      results[index]=n07ResultOk(index,item,{code:found.code,location:found.location,slot:found.slot,pinType:found.pinType,storedAt:found.storedAt});
      success.push(found);
      delete byCode[upper];
    });
    if (success.length) {
      n07DeleteSheetRowsGrouped(dataSheet(SHEET_TON), deleteRows);
      const hs = dataSheet(SHEET_LS);
      hs.getRange(hs.getLastRow()+1,1,histRows.length,9).setValues(histRows);
      applyLocationDeltasBatch(deltas);
      SpreadsheetApp.flush();
    }
    return {ok:true,count:items.length,success:success.length,failed:items.length-success.length,results:results};
  } finally { lock.releaseLock(); }
}

function n07RunGenericMutation(action, payload, parentReq) {
  const p = payload && typeof payload === 'object' ? payload : {};
  p.operatorId = clean(parentReq.operatorId);
  p.deviceId = clean(parentReq.deviceId);
  p._batchSync = true;
  switch (clean(action)) {
    case 'addLocationsExplicit': return addLocationsExplicit(p);
    case 'addLocations': return addLocations(p);
    case 'saveRackLabel': return saveRackLabel(p);
    case 'saveLayoutConfig': return saveLayoutConfig(p);
    case 'replacePin': return replacePin(p);
    case 'saveAudit': return saveAudit(p);
    default: return {ok:false,code:'batch_action_not_allowed',message:'Action không hỗ trợ batch: ' + clean(action)};
  }
}

function batchMutations(req) {
  const parsed = n07BatchItems(req);
  if (!parsed.ok) return parsed;
  const results = [];
  parsed.items.forEach((op,index) => {
    const action = clean(op.action);
    const perm = checkActionPermission(req._user, action);
    if (perm) { results.push(n07ResultError(index,op,perm.code||'permission_denied',perm.message||'Không có quyền.')); return; }
    try {
      const r = n07RunGenericMutation(action,op.payload||{},req);
      results.push(r && r.ok ? n07ResultOk(index,op,{action:action,data:r}) : n07ResultError(index,op,(r&&r.code)||'failed',(r&&r.message)||'Thao tác thất bại.',{action:action}));
    } catch (e) { results.push(n07ResultError(index,op,'server_error',String(e&&e.message?e.message:e),{action:action})); }
  });
  SpreadsheetApp.flush();
  const okCount = results.filter(x=>x.ok).length;
  return {ok:true,count:results.length,success:okCount,failed:results.length-okCount,results:results};
}
// ===== END V25 BATCH UPLOAD =====

function logHistory(code, action, location, slot, note, deviceId, operatorId, clientTime, pinType) {
  dataSheet(SHEET_LS).appendRow([
    clean(clientTime) || nowText(), code, action, location, slot,
    note, deviceId, operatorId, clean(pinType)
  ]);
}

function parseJsonArray(value) {
  if (Array.isArray(value)) return value;
  try {
    const parsed = JSON.parse(String(value || '[]'));
    return Array.isArray(parsed) ? parsed : [];
  } catch (_) {
    return [];
  }
}

function locationRows() {
  return rowsOf(dataSheet(SHEET_VI_TRI));
}

function currentRows() {
  return rowsOf(dataSheet(SHEET_TON));
}

function historyRows() {
  return rowsOf(dataSheet(SHEET_LS));
}

function rowsOf(sheet) {
  const lastRow = sheet.getLastRow();
  const lastCol = sheet.getLastColumn();
  if (lastRow < 2 || lastCol < 1) return [];
  return sheet.getRange(2, 1, lastRow - 1, lastCol).getValues();
}

function nowText() {
  return Utilities.formatDate(
    new Date(),
    Session.getScriptTimeZone() || 'Asia/Ho_Chi_Minh',
    'dd/MM/yyyy HH:mm:ss'
  );
}

function clean(value) {
  return String(value === null || value === undefined ? '' : value).trim();
}

function naturalCompare(a, b) {
  const na = Number(a);
  const nb = Number(b);
  if (!isNaN(na) && !isNaN(nb)) return na - nb;
  return String(a).localeCompare(String(b));
}
