﻿@echo off
setlocal EnableExtensions EnableDelayedExpansion
title N07 HUBDNI ANDROID V14 - UPDATE + TEST V25

set "FLUTTER=C:\flutter\bin\flutter.bat"
set "PROJECT=C:\N07_HUB_V1"
set "VF_URL=https://script.google.com/macros/s/AKfycbzYgfa03i6DYlMdV2Djdnn0SDNO2vmqzorERgneeHnVkBMWMNPkTn2nz_k1KvCEJvBx/exec"
set "AUTO_URL=https://script.google.com/macros/s/AKfycbyX-10dNxS54Oyt-FTurp-C5iEyd_cktA6abbf-PMOyDDe-7wJrBiz-LaCrGpdluI5G/exec"

cls
echo ============================================================
echo N07 HUBDNI ANDROID V14 / API V25 - CAP NHAT + TEST
echo ============================================================
echo.
echo File nay se:
echo   1. Kiem tra 2 Backend phai la API V25.
echo   2. Backup source Android hien tai.
echo   3. Copy source V14.
echo   4. flutter pub get + analyze + test.
echo   5. Neu loi: TU KHOI PHUC source cu va DUNG.
echo.
echo KHONG build APK trong buoc nay.
echo.

if not exist "%FLUTTER%" (
  echo [LOI] Khong tim thay Flutter: %FLUTTER%
  echo Chup man hinh nay gui ChatGPT. KHONG tu tao project moi.
  goto FAIL
)
if not exist "%PROJECT%\pubspec.yaml" (
  echo [LOI] Khong tim thay project: %PROJECT%
  echo Neu project cua ban nam o noi khac, chup man hinh gui ChatGPT.
  goto FAIL
)

for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "STAMP=%%i"
set "BACKUP=C:\N07\BACKUP_ANDROID_V14_%STAMP%"
if not exist "C:\N07" mkdir "C:\N07"
mkdir "%BACKUP%" >nul 2>nul
mkdir "%BACKUP%\lib" >nul 2>nul
mkdir "%BACKUP%\test" >nul 2>nul

if exist "%PROJECT%\lib\main.dart" copy /Y "%PROJECT%\lib\main.dart" "%BACKUP%\lib\main.dart" >nul
if exist "%PROJECT%\lib\local_store.dart" copy /Y "%PROJECT%\lib\local_store.dart" "%BACKUP%\lib\local_store.dart" >nul
if exist "%PROJECT%\pubspec.yaml" copy /Y "%PROJECT%\pubspec.yaml" "%BACKUP%\pubspec.yaml" >nul
if exist "%PROJECT%\analysis_options.yaml" copy /Y "%PROJECT%\analysis_options.yaml" "%BACKUP%\analysis_options.yaml" >nul
if exist "%PROJECT%\pubspec.lock" (
  copy /Y "%PROJECT%\pubspec.lock" "%BACKUP%\pubspec.lock" >nul
) else (
  type nul > "%BACKUP%\NO_PUBSPEC_LOCK"
)
if exist "%PROJECT%\android\app\src\main\AndroidManifest.xml" copy /Y "%PROJECT%\android\app\src\main\AndroidManifest.xml" "%BACKUP%\AndroidManifest.xml" >nul
if exist "%PROJECT%\test\widget_test.dart" copy /Y "%PROJECT%\test\widget_test.dart" "%BACKUP%\test\widget_test.dart" >nul

echo [1/8] Backup source cu: %BACKUP%

echo [2/8] Kiem tra Backend VF_E2W API V25...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$u=$env:VF_URL+'?action=ping&warehouseId=VF_E2W&_ts='+[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds(); try{$r=Invoke-RestMethod -Uri $u -TimeoutSec 30}catch{Write-Host $_.Exception.Message;exit 40}; Write-Host ('  Kho: '+$r.warehouseId); Write-Host ('  API: '+$r.apiVersion); if(([int]$r.apiVersion)-lt 25 -or [string]$r.warehouseId -ne 'VF_E2W'){exit 41}"
if errorlevel 1 goto BACKEND_FAIL

echo [3/8] Kiem tra Backend AUTO_EV API V25...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$u=$env:AUTO_URL+'?action=ping&warehouseId=AUTO_EV&_ts='+[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds(); try{$r=Invoke-RestMethod -Uri $u -TimeoutSec 30}catch{Write-Host $_.Exception.Message;exit 42}; Write-Host ('  Kho: '+$r.warehouseId); Write-Host ('  API: '+$r.apiVersion); if(([int]$r.apiVersion)-lt 25 -or [string]$r.warehouseId -ne 'AUTO_EV'){exit 43}"
if errorlevel 1 goto BACKEND_FAIL

echo [4/8] Copy source Android V14...
if not exist "%PROJECT%\test" mkdir "%PROJECT%\test"
copy /Y "%~dp0lib\main.dart" "%PROJECT%\lib\main.dart" >nul || goto COPY_FAIL
copy /Y "%~dp0lib\local_store.dart" "%PROJECT%\lib\local_store.dart" >nul || goto COPY_FAIL
copy /Y "%~dp0pubspec.yaml" "%PROJECT%\pubspec.yaml" >nul || goto COPY_FAIL
copy /Y "%~dp0analysis_options.yaml" "%PROJECT%\analysis_options.yaml" >nul || goto COPY_FAIL
copy /Y "%~dp0AndroidManifest.xml" "%PROJECT%\android\app\src\main\AndroidManifest.xml" >nul || goto COPY_FAIL
copy /Y "%~dp0test\widget_test.dart" "%PROJECT%\test\widget_test.dart" >nul || goto COPY_FAIL

cd /d "%PROJECT%"
echo [5/8] Flutter pub get...
call "%FLUTTER%" pub get
if errorlevel 1 goto COMPILE_FAIL

echo [6/8] Flutter analyze...
call "%FLUTTER%" analyze --no-fatal-infos --no-fatal-warnings
if errorlevel 1 goto COMPILE_FAIL

echo [7/8] Flutter test...
call "%FLUTTER%" test "test\widget_test.dart"
if errorlevel 1 goto COMPILE_FAIL

echo [8/8] Kiem tra Flutter devices...
call "%FLUTTER%" devices

echo.
echo ============================================================
echo PASS: SOURCE V14 DA CAP NHAT + ANALYZE/TEST THANH CONG.
echo Backup: %BACKUP%
echo.
echo DE TEST PIXEL 7:
echo   Mo Android Studio - Device Manager - bat Pixel 7.
echo   Sau do co the bam Run trong Android Studio,
echo   HOAC bam file 03_RUN_DEBUG_PIXEL7_N07_HUBDNI_ANDROID_V14_V25.bat
echo.
echo CHUA CAN build APK release luc nay.
echo ============================================================
pause
goto END

:BACKEND_FAIL
echo.
echo ============================================================
echo [DUNG] Backend chua dung API V25 hoac sai kho.
echo KHONG COPY SOURCE. KHONG BUILD APK.
echo.
echo VF phai tra warehouseId=VF_E2W va apiVersion >= 25.
echo AUTO phai tra warehouseId=AUTO_EV va apiVersion >= 25.
echo Chup NGUYEN cua so nay gui ChatGPT.
echo ============================================================
pause
goto END

:COPY_FAIL
echo [LOI] Copy source that bai. Khoi phuc source cu...
call :RESTORE_BACKUP
goto FAIL

:COMPILE_FAIL
echo.
echo ============================================================
echo [DUNG] Flutter analyze/test KHONG PASS.
echo Dang khoi phuc source cu: %BACKUP%
call :RESTORE_BACKUP
echo CHUP NGUYEN Build Output / cua so nay gui ChatGPT.
echo KHONG chay file build release.
echo ============================================================
pause
goto END

:RESTORE_BACKUP
if exist "%BACKUP%\lib\main.dart" copy /Y "%BACKUP%\lib\main.dart" "%PROJECT%\lib\main.dart" >nul
if exist "%BACKUP%\lib\local_store.dart" copy /Y "%BACKUP%\lib\local_store.dart" "%PROJECT%\lib\local_store.dart" >nul
if exist "%BACKUP%\pubspec.yaml" copy /Y "%BACKUP%\pubspec.yaml" "%PROJECT%\pubspec.yaml" >nul
if exist "%BACKUP%\analysis_options.yaml" copy /Y "%BACKUP%\analysis_options.yaml" "%PROJECT%\analysis_options.yaml" >nul
if exist "%BACKUP%\pubspec.lock" copy /Y "%BACKUP%\pubspec.lock" "%PROJECT%\pubspec.lock" >nul
if exist "%BACKUP%\NO_PUBSPEC_LOCK" if exist "%PROJECT%\pubspec.lock" del /Q "%PROJECT%\pubspec.lock"
if exist "%BACKUP%\AndroidManifest.xml" copy /Y "%BACKUP%\AndroidManifest.xml" "%PROJECT%\android\app\src\main\AndroidManifest.xml" >nul
if exist "%BACKUP%\test\widget_test.dart" copy /Y "%BACKUP%\test\widget_test.dart" "%PROJECT%\test\widget_test.dart" >nul
echo Source cu da duoc khoi phuc.
exit /b 0

:FAIL
echo.
echo CAP NHAT KHONG THANH CONG.
pause
:END
endlocal
