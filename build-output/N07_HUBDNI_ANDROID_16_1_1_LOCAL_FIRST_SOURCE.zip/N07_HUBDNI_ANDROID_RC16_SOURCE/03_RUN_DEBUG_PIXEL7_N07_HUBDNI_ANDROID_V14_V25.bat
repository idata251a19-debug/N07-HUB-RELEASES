﻿@echo off
setlocal EnableExtensions
title N07 HUBDNI ANDROID V14 - RUN DEBUG PIXEL 7
set "FLUTTER=C:\flutter\bin\flutter.bat"
set "PROJECT=C:\N07_HUB_V1"
cls
echo ============================================================
echo TEST TRUC TIEP TREN PIXEL 7 EMULATOR
ECHO ============================================================
echo.
echo 1. Mo Android Studio.
echo 2. Device Manager - bat Pixel 7 va doi vao man hinh Android.
echo 3. Quay lai cua so nay va bam phim bat ky.
echo.
pause
if not exist "%FLUTTER%" (
  echo [LOI] Khong thay Flutter: %FLUTTER%
  pause
  goto END
)
if not exist "%PROJECT%\pubspec.yaml" (
  echo [LOI] Khong thay project Flutter: %PROJECT%
  pause
  goto END
)
cd /d "%PROJECT%"
echo Danh sach thiet bi:
call "%FLUTTER%" devices
echo.
echo Dang chay Flutter debug. Neu co nhieu device, Flutter co the yeu cau chon device.
echo De dung app: bam q trong cua so nay.
echo.
call "%FLUTTER%" run
if errorlevel 1 (
  echo.
  echo [LOI] Run debug that bai. Chup Build Output / loi nay gui ChatGPT.
  pause
)
:END
endlocal
