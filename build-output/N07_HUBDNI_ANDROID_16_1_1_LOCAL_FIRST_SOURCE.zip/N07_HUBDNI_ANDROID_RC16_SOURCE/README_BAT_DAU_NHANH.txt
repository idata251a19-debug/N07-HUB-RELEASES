N07 HUBDNI ANDROID V14 / API V25 — BẮT ĐẦU NHANH

0) Cập nhật cả 2 Backend lên V25 bằng Edit deployment -> New version.
1) Giải nén gói Android.
2) Chạy 01_UPDATE_SOURCE_AND_TEST_N07_HUBDNI_ANDROID_V14_V25.bat
3) Chỉ khi PASS: mở Android Studio → bật Pixel 7 → Run.
   Hoặc chạy 03_RUN_DEBUG_PIXEL7_N07_HUBDNI_ANDROID_V14_V25.bat
4) Test VF ↔ AUTO, Nhập/Xuất/Tìm/Tồn/Vị trí/Kiểm kê/Lịch sử.
   Lần đầu mở mỗi hạng mục phải có mạng để tải snapshot thật.
5) Chỉ khi Pixel 7 ổn mới chạy 02_BUILD_APK_RELEASE_N07_HUBDNI_ANDROID_V14_V25.bat
6) APK release: C:\N07\N07_HUBDNI_ANDROID_V14_V25_UNIVERSAL.apk

Nếu bước 01 hoặc Android Studio báo lỗi: CHỤP NGUYÊN LỖI, không tự sửa backend/Sheet.
Gói source không kèm APK chưa được Flutter compile. Chỉ dùng APK do bước 6 vừa tạo.
Đối chiếu file SHA256.txt sau khi giải nén để phát hiện file bị thay đổi.
