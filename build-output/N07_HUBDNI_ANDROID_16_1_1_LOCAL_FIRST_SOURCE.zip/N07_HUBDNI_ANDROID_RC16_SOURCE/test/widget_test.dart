import 'package:flutter_test/flutter_test.dart';
import 'package:n07_hub_v1/main.dart';

void main() {
  test('RC16 keeps both VinFast PIN warehouses and Supabase endpoints', () {
    expect(kWarehouseVf, 'VF_E2W');
    expect(kWarehouseAuto, 'AUTO_EV');
    expect(kWarehouseVfLabel, 'PIN XE MÁY ĐIỆN VINFAST');
    expect(kWarehouseAutoLabel, 'PIN Ô TÔ ĐIỆN VINFAST');
    expect(kBuiltInVfServerUrl, contains('/functions/v1/n07-api-v4'));
    expect(kBuiltInAutoServerUrl, contains('/functions/v1/n07-api-v4'));
    expect(kSupabaseHistoryUrl, contains('/functions/v1/n07-history-v4'));
  });

  test('Android scope is field-only and excludes offline/admin PC features', () {
    expect(kAndroidFieldFeatures, contains('NHAP_PIN'));
    expect(kAndroidFieldFeatures, contains('XUAT_PIN'));
    expect(kAndroidFieldFeatures, contains('TON_KHO'));
    expect(kAndroidFieldFeatures, contains('TIM_PIN'));
    expect(kAndroidFieldFeatures, contains('VI_TRI_READ_ONLY'));
    expect(kAndroidFieldFeatures, contains('LICH_SU'));
    expect(kAndroidFieldFeatures, isNot(contains('OFFLINE_SYNC')));
    expect(kPcOnlyFeatures, contains('USER_ADMIN'));
    expect(kPcOnlyFeatures, contains('LAYOUT_EDIT'));
    expect(kAndroidFieldFeatures.intersection(kPcOnlyFeatures), isEmpty);
  });

  test('warehouse labels never fall back to a mixed generic label', () {
    expect(warehouseLabel(kWarehouseVf), kWarehouseVfLabel);
    expect(warehouseLabel(kWarehouseAuto), kWarehouseAutoLabel);
  });

  test('QR pair comparison remains exact after outer trim', () {
    expect(qrCodesMatchExact('ABC123', 'ABC123'), isTrue);
    expect(qrCodesMatchExact('  ABC123  ', 'ABC123'), isTrue);
    expect(qrCodesMatchExact('ABC123', 'abc123'), isFalse);
    expect(qrCodesMatchExact('', ''), isFalse);
  });
}
