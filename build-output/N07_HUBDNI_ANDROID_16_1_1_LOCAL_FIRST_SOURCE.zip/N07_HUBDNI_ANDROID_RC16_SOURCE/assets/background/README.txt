RC16 background placeholder.
When the final background image is ready, add it here and register the asset in pubspec.yaml; no business logic change is required.
