# HƯỚNG DẪN N07 HUBDNI ANDROID V14 / API V25 — DÀNH CHO NGƯỜI MỚI

## Mục tiêu
Android V14 đồng bộ nghiệp vụ hiện trường với **N07 HUBDNI PC v2.5.0 / Backend V25**.

Android giữ các phần cần khi cầm điện thoại đi thao tác:
- Đăng nhập User dùng chung.
- Chuyển **PIN XE MÁY ĐIỆN VINFAST** / **PIN Ô TÔ ĐIỆN VINFAST**.
- Nhập PIN, Xuất PIN, Tìm PIN, Tồn kho.
- Xem vị trí theo đúng từng hạng mục:
  - Xe máy điện: Dãy → Kệ → **4 Ô cố định** → Slot.
  - Ô tô điện: Dãy → Kệ → **Vị trí 1–6 theo cấu hình PC** → Slot.
- Kiểm kê theo Dãy, lưu đủ Khớp / Thiếu / Sai vị trí / Ngoài hệ thống / Trùng.
- Xem lịch sử gần đây.
- Gán Loại pin khi nhập.
- Xác nhận thao tác và cơ chế 5 phút.
- Đồng bộ revision 5 giây khi app đang hoạt động.
- Đối chiếu QR thùng/PIN **chỉ ở Xe máy điện VinFast**.

Các phần cố ý chỉ để trên PC:
- Thêm/Xóa Dãy.
- Đổi tên Dãy/Kệ/Ô/Vị trí và thay đổi layout.
- Quản trị User.
- Đổi mật khẩu ADMIN.
- Chỉnh Backend URL.
- Server Master.
- Báo cáo Excel quản trị đầy đủ.

Lý do: đây là thao tác quản trị/rủi ro, làm trên màn hình PC dễ kiểm tra hơn và giảm khả năng sửa nhầm tại hiện trường.

User thường cần đổi mật khẩu thì chuyển sang **PIN XE MÁY ĐIỆN** trước, vì
User Master và cache đăng nhập offline dùng VF_E2W. ADMIN đổi mật khẩu trên PC.

---

## BƯỚC 0 — Cập nhật Backend V25 trước

Android V14 yêu cầu cả hai backend trả `apiVersion >= 25` và đúng chính xác
`warehouseId` tương ứng. App sẽ chặn nếu gán nhầm URL VF/AUTO.

Hãy cập nhật theo file V25 đi cùng gói PC:
- `Code_VF_E2W_V25.gs`
- `Code_AUTO_EV_V25.gs`

Cách an toàn: **Deploy → Manage deployments → Edit deployment hiện tại → New version → Deploy**.

Không tạo deployment mới nếu deployment hiện tại vẫn dùng được, để URL Android không thay đổi.

---

## BƯỚC 1 — Chạy file 01

Giải nén gói Android V14, sau đó double-click:

`01_UPDATE_SOURCE_AND_TEST_N07_HUBDNI_ANDROID_V14_V25.bat`

File này tự làm:
1. Kiểm tra Flutter và project `C:\N07_HUB_V1`.
2. Backup source Android cũ vào `C:\N07\BACKUP_ANDROID_V14_...`.
3. Ping Backend VF_E2W và AUTO_EV, bắt buộc API V25.
4. Copy source V14.
5. `flutter pub get`.
6. `flutter analyze`.
7. `flutter test`.
8. Hiện danh sách thiết bị Flutter.

Nếu analyze/test lỗi, script **tự phục hồi source cũ** và dừng.

Nếu thấy `PASS`, mới sang bước Pixel 7.

---

## BƯỚC 2 — Test bằng Pixel 7 Emulator trong Android Studio

Bạn đã có Pixel 7 nên ưu tiên test ở đây trước.

### Cách A — dùng Android Studio
1. Mở Android Studio.
2. Mở project: `C:\N07_HUB_V1`.
3. Device Manager → bật **Pixel 7**.
4. Chờ Pixel 7 vào màn hình Android.
5. Trên thanh thiết bị chọn Pixel 7.
6. Bấm **Run ▶**.

### Cách B — dùng file BAT
Bật Pixel 7 trước, rồi chạy:

`03_RUN_DEBUG_PIXEL7_N07_HUBDNI_ANDROID_V14_V25.bat`

Script sẽ chạy `flutter devices` rồi `flutter run`.

---

## BƯỚC 3 — Những bài test bắt buộc trên Pixel 7

### A. Login / chuyển kho
1. Login bằng ADMIN hoặc HUBDNI.
2. Mở Xe máy điện VinFast.
3. Chuyển sang Ô tô điện VinFast.
4. Quay lại Xe máy.
5. Dữ liệu hai kho không được lẫn.

### B. Cấu hình Dãy từ PC → Android
Trên PC, tạo hai Dãy test riêng:

- VF_E2W: chọn một Dãy test, Android phải luôn hiện đúng **4 Ô/Kệ**.
- AUTO_EV: chọn một Dãy test và đặt **6 Vị trí/Kệ** trên PC.
- Có thể đặt 12 Slot/Ô hoặc Vị trí để kiểm tra giới hạn Slot.

Chờ đồng bộ, mở đúng Dãy trên Pixel 7. Android phải hiện đúng quy tắc của
từng hạng mục và không được hiện dữ liệu kho còn lại.

Android **không có nút sửa cấu hình Dãy**. Muốn đổi cấu trúc, quay về PC.

Lần đầu mở một hạng mục trên điện thoại phải có mạng để tải snapshot. Nếu tải
không thành công, app tự quay về hạng mục trước và không cho nhập vào Dãy giả.

### C. Nhập PIN
1. VF chọn Dãy → Kệ → Ô; AUTO chọn Dãy → Kệ → Vị trí.
2. Quét mã test.
3. Kiểm tra vị trí đúng Slot cho phép của Ô.
4. Kiểm tra trạng thái xác nhận/pending.
5. Kiểm tra Server và PC nhận thay đổi.

### D. Xuất PIN
1. Chọn một PIN đang tồn.
2. Xuất và xác nhận.
3. PIN phải biến mất khỏi tồn của đúng kho.
4. PC phải nhận thay đổi qua sync.

### E. Tìm PIN
- PIN đang tồn → báo đang tồn và vị trí.
- PIN đã xuất → vẫn tìm được lịch sử nếu backend có lịch sử.

### F. Kiểm kê
- Chọn Dãy cần kiểm kê trước khi quét.
- Quét mã bằng camera hoặc máy quét cầm tay.
- Kiểm tra Khớp / Thiếu / Sai vị trí / Ngoài hệ thống / Trùng.
- Bấm **LƯU KIỂM KÊ** và kiểm tra PC/Backend nhận phiên kiểm kê.

### G. QR
- Xe máy điện VinFast → có Đối chiếu QR thùng/PIN.
- Ô tô điện VinFast → không có chức năng này.

---

## BƯỚC 4 — Chỉ build APK sau khi Pixel 7 ổn

Chạy:

`02_BUILD_APK_RELEASE_N07_HUBDNI_ANDROID_V14_V25.bat`

Nếu thành công, APK nằm tại:

`C:\N07\N07_HUBDNI_ANDROID_V14_V25_UNIVERSAL.apk`

Cài trên **1 điện thoại thật để UAT trước**, chưa cài hàng loạt ngay.

---

## Khi có lỗi

Không tự sửa Google Sheet/Apps Script theo phỏng đoán.

Nếu lỗi ở Android Studio:
- chụp toàn bộ **Build Output / Run**;
- cho biết đang test VF_E2W hay AUTO_EV;
- nếu là lỗi backend, chụp PC → Cài đặt → Kiểm tra 2 Backend.

Như vậy sẽ xác định đúng lớp lỗi trước khi thay code.
