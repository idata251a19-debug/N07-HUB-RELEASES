"""Verify that bundled V25 backends match the reviewed PC v2.5 sources."""

from hashlib import sha256
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1] / "google_sheet_backend"
EXPECTED = {
    "Code.gs": "5cfecca54d9b676e23ccaf545dbbeda793d86054b9ef54ea9ad35ea67486b1ba",
    "Code_VF_E2W_V25.gs": "5cfecca54d9b676e23ccaf545dbbeda793d86054b9ef54ea9ad35ea67486b1ba",
    "Code_AUTO_EV_V25.gs": "e78f044a2b64e8d18ebc10e25edcb75a7a54e47c176a547ae53b86f0d5ba97b8",
}

for name, expected in EXPECTED.items():
    actual = sha256((ROOT / name).read_bytes()).hexdigest()
    assert actual == expected, f"{name}: expected {expected}, got {actual}"

print("PASS backend hashes: Code.gs=VF V25; VF/AUTO match PC v2.5")
