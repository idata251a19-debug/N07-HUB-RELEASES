# QA SOURCE — N07 HUBDNI ANDROID V14 / API V25

## Kiểm tra thực hiện trong môi trường build hiện tại
- `kRequiredApiVersion = 25`: PASS.
- Phiên bản source: `14.0.0+42`: PASS.
- Nhãn VF_E2W / AUTO_EV đúng: PASS.
- Phản hồi Backend sai `warehouseId` bị chặn: PASS static.
- Mọi phản hồi thành công có API < 25 bị chặn: PASS static.
- Backend VF V25 JavaScript syntax (`node --check`): PASS.
- Backend AUTO V25 JavaScript syntax (`node --check`): PASS.
- Backend V25 có `batchImportPins` / `batchExportPins`: PASS static.
- Dấu ngoặc source Dart cân bằng: PASS static.
- VF luôn 4 Ô/Kệ; AUTO clamp Vị trí 1–6/Kệ: PASS static.
- Cell picker đổi đúng thuật ngữ Ô/Vị trí: PASS static.
- Slot per cell dùng cấu hình, tối đa 18: PASS static.
- SQLite local chặn aisle/cell/slot ngoài layout: PASS static.
- Đối chiếu QR chỉ render khi warehouse = VF_E2W: PASS static.
- Android không có nút đổi tên/cấu hình Kệ/Ô/Vị trí/Slot: PASS static.
- Trang Vị trí Android không có nút Thêm/Xóa Dãy: PASS static.
- Home không mở User admin, Excel, Server Master: PASS static.
- Kiểm kê chọn Dãy và lưu Khớp/Thiếu/Sai vị trí/Ngoài hệ thống/Trùng: PASS static.
- User/Auth vẫn dùng VF User Master: PASS static.
- Hai warehouse ID riêng `VF_E2W` / `AUTO_EV`: PASS static.
- Hai file SQLite riêng và cảnh báo pending khi chuyển kho: PASS static.
- Lịch sử tìm PIN gần đây tách key theo warehouse: PASS static.
- Chặn chuyển kho khi sync và bắt buộc snapshot lần đầu: PASS static.
- Database mới không tạo Dãy giả trước snapshot: PASS static.
- Dashboard/danh sách Dãy dùng capacity layout thực: PASS static.
- Màn Tồn không nạp kèm history/audit/location payload kiểu Excel: PASS static.
- Chi tiết Dãy chỉ materialize slot thuộc layout, cập nhật theo slot ID: PASS static.
- Exhaustive slot contract: 4.320 ID duy nhất, VF 432, AUTO max 648: PASS.
- Module/dependency Excel, User admin, URL/layout admin và đổi pass ADMIN đã
  xóa khỏi source Android: PASS static.
- Không còn mật khẩu legacy hard-code trong source Flutter: PASS static.
- Đổi mật khẩu User chỉ cho phép tại VF User Master; đổi pass ADMIN ở PC: PASS static.
- Upload outbox Android giới hạn 10 op/request: PASS static.
- `pubspec.yaml` parse được và đúng dependency allowlist: PASS.
- `AndroidManifest.xml` parse được; toàn bộ file text UTF-8: PASS.
- Backend VF/AUTO: batch import 50 dùng 1 `setValues`, batch export 50 dùng 1
  grouped delete và 1 history `setValues`: PASS deterministic test.
- Backend VF khớp byte PC v2.5: `5cfecca54d9b676e23ccaf545dbbeda793d86054b9ef54ea9ad35ea67486b1ba`.
- Backend AUTO khớp byte PC v2.5: `e78f044a2b64e8d18ebc10e25edcb75a7a54e47c176a547ae53b86f0d5ba97b8`.

Lệnh QA chạy trong gói:

```text
python test/static_qa_v25.py
python test/qa_slot_layout_v25.py
python test/qa_backend_hashes_v25.py
node --check < google_sheet_backend/Code_VF_E2W_V25.gs
node --check < google_sheet_backend/Code_AUTO_EV_V25.gs
node test/qa_backend_v25.js Code_VF_E2W_V25.gs
node test/qa_backend_v25.js Code_AUTO_EV_V25.gs
```

## Giới hạn QA
Container hiện tại không có Flutter/Dart/Android SDK, vì vậy **không tuyên bố
compile Flutter hoặc APK đã PASS tại đây**. Gói này không kèm APK dựng giả.

File `01_UPDATE_SOURCE_AND_TEST...bat` bắt buộc chạy trên máy Windows có Flutter
trước khi source được coi là compile-ready. Script backup cả `pubspec.lock` và
tự restore nếu `flutter pub get`, `flutter analyze` hoặc `flutter test` thất bại.

Sau đó phải test Pixel 7 Emulator trước khi build APK release.
