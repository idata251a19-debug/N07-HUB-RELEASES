# PHẠM VI ĐỒNG BỘ ANDROID V14 ↔ PC V2.5

## Nguyên tắc

- **Android = thao tác hiện trường nhanh.**
- **PC = quản trị cấu trúc, quyền và báo cáo đầy đủ.**
- Cùng Backend V25 và cùng dữ liệu nghiệp vụ.
- VF_E2W và AUTO_EV vẫn là hai kho vật lý độc lập.
- User/Auth dùng chung từ VF_E2W User Master.

| Chức năng | Android | PC |
|---|---:|---:|
| Login chung | ✓ | ✓ |
| Chuyển VF / AUTO | ✓ | ✓ |
| Nhập PIN | ✓ | ✓ |
| Xuất PIN | ✓ | ✓ |
| Gán Loại PIN khi nhập | ✓ | ✓ |
| Tìm PIN / lịch sử PIN | Xem | Xem + xuất hàng loạt |
| Tồn kho | ✓ | ✓ |
| Xem Dãy/Kệ/Ô hoặc Vị trí/Slot | Chỉ đọc | ✓ |
| Kiểm kê | Quét + lưu | Quản trị/đối chiếu |
| Lịch sử giao dịch | Gần đây | Đầy đủ |
| Đối chiếu QR thùng/PIN | Chỉ VF | Trang chủ/logic PC |
| Tạo QR offline quản trị/in tem | — | ✓ |
| Thêm/Xóa Dãy | — | ✓ |
| Đổi số Kệ/Ô/Slot mỗi Dãy | Chỉ đọc | ✓ |
| Xóa Dãy + Pass cấp 2 | — | ✓ |
| Quản trị User | — | ✓ |
| Đổi mật khẩu ADMIN | — | ✓ |
| Backend URL / binding | — | ADMIN PC |
| Server Master | — | ADMIN PC |
| Excel quản trị đầy đủ | — | ✓ |

## Cấu trúc vị trí V25

Quy tắc hiển thị/nghiệp vụ:

- `VF_E2W`: Dãy → Kệ → **4 Ô cố định** → 1–18 Slot/Ô.
- `AUTO_EV`: Dãy → Kệ → **1–6 Vị trí tùy cấu hình PC** → 1–18 Slot/Vị trí.
- Số Kệ/Dãy: 1–6 theo cấu hình PC.

Android đọc các label:
- `SO_DAY` = số Kệ sử dụng
- `SO_O` = số Vị trí/Kệ của AUTO; VF luôn ép về 4 Ô
- `SO_PIN_O` = số Slot/Ô hoặc Vị trí sử dụng

Android không sửa các giá trị trên.

Slot ID nội bộ cũ vẫn giữ envelope 4.320/Dãy để không phá dữ liệu V8–V13.
Android chỉ mở các slot thuộc layout V25; local SQLite cũng chặn ghi ra ngoài
layout, không chỉ chặn ở giao diện.

## Tách dữ liệu hai hạng mục

- VF local: `n07_hub_offline_v4.db`.
- AUTO local: `n07_hub_auto_ev_v1.db`.
- Mỗi request mang `warehouseId`; phản hồi sai identity bị chặn trước khi ghi local.
- Chuyển hạng mục không xóa hàng chờ. Nếu kho hiện tại còn pending, Android
  cảnh báo trước khi chuyển; nếu sync đang chạy thì chưa cho chuyển.
- Hạng mục chưa có snapshot bắt buộc tải dữ liệu lần đầu. Thất bại sẽ quay về
  hạng mục trước; database mới không tự sinh Dãy `01–04`.
- User/Auth dùng VF User Master; dữ liệu tồn, lịch sử, vị trí và kiểm kê không
  fallback giữa hai kho.

## Upload Android và batch PC

- Android ghi từng thao tác hiện trường vào outbox có `opId`, User và thiết bị;
  xác nhận thủ công hoặc tự gửi sau 5 phút.
- Android gửi tối đa 10 thao tác mỗi `syncBatch` để retry/cô lập theo từng op.
- PC dùng endpoint batch V25 tối đa 50 PIN/lượt và tự chia nhỏ khi lỗi. Hai cơ
  chế cùng Backend V25 nhưng phục vụ hai kiểu thao tác khác nhau.
