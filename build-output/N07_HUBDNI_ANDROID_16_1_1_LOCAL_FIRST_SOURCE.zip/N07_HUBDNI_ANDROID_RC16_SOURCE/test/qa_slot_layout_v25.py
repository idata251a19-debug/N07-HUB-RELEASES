"""Exhaustive contract check for the legacy 4320 slot envelope."""

LEGACY_AISLES = 3
LEGACY_ROWS = 6
AISLES = 6
ROWS = 10
CELLS = 4
BASE_PINS = 16
PINS = 18
LEGACY_CAPACITY = LEGACY_AISLES * LEGACY_ROWS * CELLS * BASE_PINS
EXTENDED_ROWS_SLOTS = LEGACY_AISLES * (ROWS - LEGACY_ROWS) * CELLS * BASE_PINS
BASE_CAPACITY = AISLES * ROWS * CELLS * BASE_PINS
CAPACITY = AISLES * ROWS * CELLS * PINS


def base_slot(aisle: int, row: int, cell: int, pin: int) -> int:
    if aisle <= LEGACY_AISLES and row <= LEGACY_ROWS:
        return (((aisle - 1) * LEGACY_ROWS + row - 1) * CELLS + cell - 1) * BASE_PINS + pin
    if aisle <= LEGACY_AISLES:
        per_aisle = (ROWS - LEGACY_ROWS) * CELLS * BASE_PINS
        return (
            LEGACY_CAPACITY
            + (aisle - 1) * per_aisle
            + (row - LEGACY_ROWS - 1) * CELLS * BASE_PINS
            + (cell - 1) * BASE_PINS
            + pin
        )
    extended_end = LEGACY_CAPACITY + EXTENDED_ROWS_SLOTS
    per_aisle = ROWS * CELLS * BASE_PINS
    return (
        extended_end
        + (aisle - LEGACY_AISLES - 1) * per_aisle
        + (row - 1) * CELLS * BASE_PINS
        + (cell - 1) * BASE_PINS
        + pin
    )


def slot(aisle: int, row: int, cell: int, pin: int) -> int:
    if pin <= BASE_PINS:
        return base_slot(aisle, row, cell, pin)
    ordinal = ((aisle - 1) * ROWS + row - 1) * CELLS + cell - 1
    return BASE_CAPACITY + ordinal * (PINS - BASE_PINS) + pin - BASE_PINS


all_slots = {
    slot(aisle, row, cell, pin)
    for aisle in range(1, AISLES + 1)
    for row in range(1, ROWS + 1)
    for cell in range(1, CELLS + 1)
    for pin in range(1, PINS + 1)
}
assert len(all_slots) == CAPACITY == 4320
assert min(all_slots) == 1 and max(all_slots) == CAPACITY
assert all_slots == set(range(1, CAPACITY + 1))


def configured_slots(aisles: int, positions: int, pins: int) -> set[int]:
    result: set[int] = set()
    for aisle in range(1, aisles + 1):
        for flat in range(1, positions + 1):
            row = (flat - 1) // CELLS + 1
            cell = (flat - 1) % CELLS + 1
            for pin in range(1, pins + 1):
                result.add(slot(aisle, row, cell, pin))
    return result


vf = configured_slots(6, 4, 18)
auto = configured_slots(6, 6, 18)
assert len(vf) == 432
assert len(auto) == 648
assert vf < auto < all_slots
assert slot(1, 1, 1, 17) == 3841
assert slot(6, 10, 4, 18) == 4320

print("PASS slot/layout QA: envelope=4320, VF=432, AUTO(max)=648, mapping unique")
