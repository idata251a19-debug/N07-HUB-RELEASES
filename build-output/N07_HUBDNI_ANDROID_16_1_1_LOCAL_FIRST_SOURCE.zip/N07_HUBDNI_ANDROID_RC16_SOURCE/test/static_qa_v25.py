from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "lib" / "main.dart").read_text(encoding="utf-8")
STORE = (ROOT / "lib" / "local_store.dart").read_text(encoding="utf-8")
PUBSPEC = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
WIDGET_TEST = (ROOT / "test" / "widget_test.dart").read_text(encoding="utf-8")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def balanced_dart(source: str, name: str) -> None:
    pairs = {')': '(', ']': '[', '}': '{'}
    stack: list[tuple[str, int]] = []
    i = 0
    line = 1
    quote = ""
    triple = False
    raw = False
    block_comment = 0
    line_comment = False

    while i < len(source):
        ch = source[i]
        nxt = source[i + 1] if i + 1 < len(source) else ""
        if ch == "\n":
            line += 1
            line_comment = False
            i += 1
            continue
        if line_comment:
            i += 1
            continue
        if block_comment:
            if ch == "/" and nxt == "*":
                block_comment += 1
                i += 2
            elif ch == "*" and nxt == "/":
                block_comment -= 1
                i += 2
            else:
                i += 1
            continue
        if quote:
            if triple and source.startswith(quote * 3, i):
                quote = ""
                triple = False
                raw = False
                i += 3
            elif not triple and ch == quote and (raw or source[i - 1] != "\\"):
                quote = ""
                raw = False
                i += 1
            elif not raw and ch == "\\":
                i += 2
            else:
                i += 1
            continue
        if ch == "/" and nxt == "/":
            line_comment = True
            i += 2
            continue
        if ch == "/" and nxt == "*":
            block_comment = 1
            i += 2
            continue
        if ch in "rR" and nxt in "'\"":
            raw = True
            ch = nxt
            i += 1
        if ch in "'\"":
            quote = ch
            triple = source.startswith(ch * 3, i)
            i += 3 if triple else 1
            continue
        if ch in "([{":
            stack.append((ch, line))
        elif ch in ")]}":
            require(bool(stack), f"{name}:{line}: closing {ch} without opener")
            opener, opener_line = stack.pop()
            require(
                opener == pairs[ch],
                f"{name}:{line}: {ch} mismatches {opener} from line {opener_line}",
            )
        i += 1

    require(not quote, f"{name}: unterminated string")
    require(block_comment == 0, f"{name}: unterminated block comment")
    if stack:
        raise AssertionError(f"{name}: unclosed delimiter {stack[-1]}")


def section(source: str, start: str, end: str) -> str:
    begin = source.index(start)
    finish = source.index(end, begin)
    return source[begin:finish]


balanced_dart(MAIN, "lib/main.dart")
balanced_dart(STORE, "lib/local_store.dart")
balanced_dart(WIDGET_TEST, "test/widget_test.dart")

require("version: 14.0.0+42" in PUBSPEC, "wrong Android source version")
for removed_dependency in ("excel:", "path_provider:", "share_plus:"):
    require(
        removed_dependency not in PUBSPEC,
        f"PC-only dependency remains: {removed_dependency}",
    )
require("const int kRequiredApiVersion = 25;" in MAIN, "API V25 is not required")
require("wrong_warehouse_backend" in MAIN, "backend identity guard missing")
require("responseApiVersion < kRequiredApiVersion" in MAIN, "global API version guard missing")
require("N07-HUBDNI-ANDROID/14.0" in MAIN, "old Android user agent")
require("import 'dart:io';" in MAIN, "SocketException import missing")

require("return kVfCellsPerAisle;" in MAIN, "VF fixed 4-cell policy missing")
require("kAutoMaxPositionsPerAisle = 6" in MAIN, "AUTO 1-6 policy missing")
require("_kVfCellsPerAisle = 4" in STORE, "local VF policy missing")
require("_kAutoMaxPositionsPerAisle = 6" in STORE, "local AUTO policy missing")
require("_slotAllowed(slot, config)" in STORE, "local layout guard missing")
require(".take(config.slotsPerCell)" in STORE, "local slot limit missing")
location_detail_store = section(
    STORE,
    "Future<Map<String, dynamic>?> getLocation",
    "Future<Map<String, String>> _positionLabels",
)
require(
    "for (final i in _allowedSlots(config))" in location_detail_store,
    "location detail still materializes all 4320 legacy slots",
)
require(
    "slots.indexWhere((item) => item.slot == outcome.slot)" in MAIN,
    "optimistic UI update still assumes dense legacy slot indexes",
)
summary = section(STORE, "Future<Map<String, dynamic>> localSummary", "Future<List<Map<String, dynamic>>> listLocations")
require("totalCapacity" in summary, "Home summary does not use layout capacity")
require("totalLocations * _kRackCapacity" not in summary, "Home still reports legacy 4320 capacity")

require("n07_hub_auto_ev_v1.db" in STORE, "AUTO local database missing")
require("n07_hub_offline_v4.db" in STORE, "VF local database missing")
require("_normalizeWarehouse" in STORE, "warehouse ID validation missing")
require(
    "n07_search_pin_recent_v1_${widget.api.warehouseId}" in MAIN,
    "recent PIN searches are shared across warehouses",
)
require(
    "Không tạo Dãy giả trên cài đặt mới" in STORE,
    "new database still relies on phantom default locations",
)

home = section(MAIN, "class _HomePageState", "class _MobileScopeNote")
require("CHỌN HẠNG MỤC PIN" in home, "dual warehouse selector missing")
require("_switchWarehouse(kWarehouseVf)" in home, "VF selector missing")
require("_switchWarehouse(kWarehouseAuto)" in home, "AUTO selector missing")
require("if (currentSync.syncing)" in home, "warehouse switch sync guard missing")
require("needsFirstSnapshot" in home, "first snapshot gate missing")
require("first_sync_required" in home, "first snapshot failure is not contained")
require("ExcelExportPage(" not in home, "Excel must not be reachable on Android")
require("UserManagementPage(" not in home, "User admin must not be reachable")
require("TransactionListsPage(" not in home, "duplicate transaction page still reachable")

location_build = section(
    MAIN,
    "class _LocationDetailPageState",
    "class _RackCellCard",
)
require("Chế độ chỉ xem" in location_build, "read-only location notice missing")
require("tooltip: 'Đổi tên" not in location_build, "rename action still visible")

audit = section(MAIN, "class _AuditPageState", "class InventoryPage")
audit_build = audit[audit.index("Widget build(BuildContext context)"):]
require("widget.api.saveAudit(" in audit, "audit is not persisted")
require("LƯU KIỂM KÊ" in audit_build, "audit save action missing")
require("XUẤT EXCEL" not in audit_build, "audit Excel action still visible")
for label in ("KHỚP", "THIẾU", "SAI VỊ TRÍ", "NGOÀI HỆ THỐNG"):
    require(label in audit_build, f"audit status missing: {label}")

location_summary = section(MAIN, "class LocationSummary", "class SlotInfo")
require("labels.capacity" not in location_summary, "old LocationSummary compile bug remains")
require("required this.capacity" in MAIN, "configured location capacity missing")
require("final String warehouseId;" in MAIN, "warehouse-aware models missing")
require("package:excel" not in MAIN, "Excel dependency remains in Android source")
require("class ExcelExportPage" not in MAIN, "Excel page remains in Android source")
require("XUẤT EXCEL" not in MAIN, "Excel action remains in Android UI")
require("class UserManagementPage" not in MAIN, "User admin remains in Android UI source")
require("Future<List<String>> addLocations" not in MAIN, "Android still creates locations")
require("Future<void> saveRackLabel" not in MAIN, "Android still edits layout labels")
require("changeAdminPassword" not in MAIN, "ADMIN password management remains on Android")
require("localPassword" not in MAIN, "legacy local password plumbing remains")
require("onServerUrlChanged" not in MAIN, "server URL is still editable on Android")
require(
    "widget.activeWarehouseId != kWarehouseVf" in MAIN,
    "password change is not bound to the VF User Master cache",
)
for legacy_secret in ("Cntt@123", "77779999", "33337777"):
    require(legacy_secret not in MAIN, "legacy hard-coded password remains")

inventory_data = section(
    STORE,
    "Future<Map<String, dynamic>> inventoryData()",
    "Future<void> refreshSyncState",
)
require(
    "'inventory':" in inventory_data and "'rackLabels':" in inventory_data,
    "mobile inventory data is incomplete",
)
for pc_only_payload in ("'locations':", "'history':", "'audits':"):
    require(
        pc_only_payload not in inventory_data,
        f"inventory still loads unnecessary payload: {pc_only_payload}",
    )

upload = section(
    MAIN,
    "Future<Map<String, dynamic>> uploadPendingTransfers",
    "Future<void> changeOwnPassword",
)
require("start += 10" in upload, "Android outbox upload is not bounded")
require("min(start + 10" in upload, "Android outbox batch size is not 10")

for backend_name, warehouse in (
    ("Code_VF_E2W_V25.gs", "VF_E2W"),
    ("Code_AUTO_EV_V25.gs", "AUTO_EV"),
):
    backend_path = ROOT / "google_sheet_backend" / backend_name
    require(backend_path.exists(), f"missing {backend_name}")
    backend = backend_path.read_text(encoding="utf-8")
    require("const API_VERSION = 25;" in backend, f"{backend_name} is not V25")
    require(
        f"const WAREHOUSE_ID = '{warehouse}';" in backend,
        f"{backend_name} has wrong warehouse identity",
    )
    require("function batchImportPins" in backend, f"{backend_name} missing batch import")
    require("function batchExportPins" in backend, f"{backend_name} missing batch export")
    require("const N07_BATCH_MAX = 50;" in backend, f"{backend_name} batch limit is not 50")

print(
    "PASS static QA: V14/API25, dual warehouse, layout policy, "
    "field-only scope, saved audit, backend identity"
)
