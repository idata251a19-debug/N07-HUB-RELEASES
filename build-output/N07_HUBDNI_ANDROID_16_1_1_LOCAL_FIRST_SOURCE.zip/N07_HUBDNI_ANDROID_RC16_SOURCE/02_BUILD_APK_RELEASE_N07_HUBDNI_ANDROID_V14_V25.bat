﻿@echo off
setlocal EnableExtensions
title N07 HUBDNI ANDROID V14 - BUILD APK RELEASE
set "FLUTTER=C:\flutter\bin\flutter.bat"
set "PROJECT=C:\N07_HUB_V1"
set "OUTPUT=C:\N07\N07_HUBDNI_ANDROID_V14_V25_UNIVERSAL.apk"
cls
echo ============================================================
echo N07 HUBDNI ANDROID V14 / API V25 - BUILD APK RELEASE
echo ============================================================
echo.
echo CHI CHAY FILE NAY SAU KHI:
echo   - file 01 da PASS;
echo   - ban da test Pixel 7 on dinh trong Android Studio.
echo.
if not exist "%FLUTTER%" goto FAIL
if not exist "%PROJECT%\pubspec.yaml" goto FAIL
cd /d "%PROJECT%"
echo [1/4] Flutter pub get...
call "%FLUTTER%" pub get
if errorlevel 1 goto FAIL
echo [2/4] Flutter analyze...
call "%FLUTTER%" analyze --no-fatal-infos --no-fatal-warnings
if errorlevel 1 goto FAIL
echo [3/4] Flutter test...
call "%FLUTTER%" test "test\widget_test.dart"
if errorlevel 1 goto FAIL
echo [4/4] Build APK release...
call "%FLUTTER%" build apk --release
if errorlevel 1 goto FAIL
if not exist "C:\N07" mkdir "C:\N07"
copy /Y "%PROJECT%\build\app\outputs\flutter-apk\app-release.apk" "%OUTPUT%" >nul
if errorlevel 1 goto FAIL
for %%A in ("%OUTPUT%") do echo APK SIZE: %%~zA bytes
certutil -hashfile "%OUTPUT%" SHA256
echo.
echo BUILD THANH CONG: %OUTPUT%
echo Cai tren 1 may TEST truoc. KHONG cai dong loat ngay.
explorer /select,"%OUTPUT%"
pause
goto END
:FAIL
echo.
echo BUILD FAILED. Khong su dung APK cu/moi theo phan doan.
echo Chup NGUYEN loi gui ChatGPT.
pause
:END
endlocal
