# SOURCE MANIFEST — N07 HUBDNI ANDROID V14 / API V25

## Source Flutter

- `lib/main.dart`: UI/luồng hiện trường, hai hạng mục, API client và guard kho.
- `lib/local_store.dart`: hai SQLite, snapshot, outbox, kiểm kê và layout guard.
- `pubspec.yaml`: phiên bản `14.0.0+42` và dependency Android tối thiểu.
- `analysis_options.yaml`, `AndroidManifest.xml`.

## Backend V25

- `google_sheet_backend/Code.gs`: alias VF_E2W.
- `google_sheet_backend/Code_VF_E2W_V25.gs`.
- `google_sheet_backend/Code_AUTO_EV_V25.gs`.

Hai file V25 khớp byte với Full Source PC v2.5 đã dùng làm nguồn chuẩn.

## QA

- `test/widget_test.dart`: cấu hình V14/V25, layout VF/AUTO, slot legacy,
  QR, timer, capacity và phạm vi mobile/PC.
- `test/static_qa_v25.py`: delimiter/source contract/dependency/scope/identity.
- `test/qa_slot_layout_v25.py`: exhaustive 4.320 slot và subset VF/AUTO.
- `test/qa_backend_hashes_v25.py`: khóa SHA-256 Backend theo PC v2.5.
- `test/qa_backend_v25.js`: deterministic batch 50 cho cả hai Backend.
- `QA_ANDROID_V14_V25.md`: kết quả và giới hạn QA.

## Script Windows

- `01_UPDATE_SOURCE_AND_TEST_N07_HUBDNI_ANDROID_V14_V25.bat`: backup, kiểm tra
  hai Backend, copy source, `pub get`, analyze, test và tự restore khi lỗi.
- `03_RUN_DEBUG_PIXEL7_N07_HUBDNI_ANDROID_V14_V25.bat`: chạy debug/UAT.
- `02_BUILD_APK_RELEASE_N07_HUBDNI_ANDROID_V14_V25.bat`: analyze, test và build
  APK release sau UAT.

## Tài liệu

- `README_BAT_DAU_NHANH.txt`.
- `HUONG_DAN_ANDROID_V14_V25_CHO_NGUOI_MOI.md`.
- `PHAM_VI_DONG_BO_ANDROID_PC_V25.md`.
- `CHANGELOG_ANDROID_V14_V25.md`.
- `SHA256.txt`: checksum từng file trong release.

## Ranh giới phát hành

Gói này là source overlay cho project Flutter hiện hữu `C:\N07_HUB_V1`, giống
cách gói Android trước được vận hành; không chứa Gradle project đầy đủ hoặc APK
chưa được build. Flutter/Dart/Android SDK không có trong môi trường review hiện
tại, nên bước compile/analyze/test thiết bị được khóa trong script Windows và
phải PASS trước khi build APK.
